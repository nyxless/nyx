package model

//此文件是由 tools/genModel 自动生成, 可按需要修改

import (
	"#[.AppName]#/model/dao"
	//"github.com/nyxless/nyx/model/dao/tx"
	"github.com/nyxless/nyx/model"
)

// 如果需要使用 context, 调用 WithContext 方法
func User() *UserModel {
	return &UserModel{}
}

type UserModel struct {
	model.Model
}

func (this *UserModel) GetUserInfo(id int) map[string]interface{} { // {{{
	data, _ := dao.NewDAOUser().GetRecord(id)
	return data
} //}}}

func (this *UserModel) AddUser() { // {{{
	//以下代码示意如何使用事务
	/*

		tx := tx.TransBegin()
		defer tx.Rollback()

		uid := dao.NewDAOUser(tx).AddRecord(map[string]interface{}{"name": "xx"})

		dao.NewDAOUserInfo(tx).AddRecord(map[string]interface{}{
			"uid":  uid,
			"info": "xxxx",
		})

		tx.Commit()

	*/
} //}}}

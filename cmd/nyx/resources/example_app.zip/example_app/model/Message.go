package model

//此文件是由 tools/genRpcModel 自动生成, 可按需要修改

import (
	"context"
	"fmt"
	"github.com/nyxless/nyx/x"
	"github.com/nyxless/nyxclient"
)

func Message(ctx context.Context) *MessageModel {
	return &MessageModel{ctx}
}

type MessageModel struct {
	Ctx context.Context
}

func (this *MessageModel) getClient() (*nyxclient.NyxClient, error) { // {{{
	conf := x.Conf.GetStringMap("rpc_client_message")
	return nyxclient.NewNyxClient(conf["host"], conf["appid"], conf["secret"])
} //}}}

func (this *MessageModel) SendMessage() (x.MAP, error) { // {{{
	c, err := this.getClient()
	if nil != err {
		return nil, err
	}

	res, err := c.Request("message/sendMessage", x.MAP{}, nyxclient.WithContext(this.Ctx))
	if err != nil {
		return nil, err
	}

	if res.GetCode() > 0 {
		return nil, fmt.Errorf("rpc client return err: %s", res.GetMsg())
	}

	return res.GetData(), nil
} // }}}

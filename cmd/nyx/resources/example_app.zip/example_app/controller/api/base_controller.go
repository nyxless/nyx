package api

import (
	"github.com/nyxless/nyx/controller"
)

type BaseController struct {
	controller.HTTP
}

func (b *BaseController) Init() { // {{{
	b.Println("base init")
} // }}}

func (b *BaseController) Final() { // {{{
	b.Println("base final")
} // }}}

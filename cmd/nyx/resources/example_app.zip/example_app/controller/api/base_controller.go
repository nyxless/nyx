package api

import (
	"github.com/nyxless/nyx/controller"
)

type BaseController struct {
	controller.HTTP
}

func (this *BaseController) Init() { // {{{
	this.Println("base init")
} // }}}

func (this *BaseController) Final() { // {{{
	this.Println("base final")
} // }}}

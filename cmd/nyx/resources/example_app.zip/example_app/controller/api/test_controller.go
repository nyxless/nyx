package api

type TestController struct {
	BaseController
}

func (this *TestController) HelloAction() { // {{{
	this.RenderText("Hello World!")
} // }}}

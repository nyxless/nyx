package api

type TestController struct {
	BaseController
}

func (t *TestController) HelloAction() { // {{{
	t.RenderText("Hello World!")
} // }}}

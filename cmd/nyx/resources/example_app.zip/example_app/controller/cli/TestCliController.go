package cli

import (
	"github.com/nyxless/nyx/controller"
	"github.com/nyxless/nyx/x"
	//"github.com/nyxless/nyxqueue"
	//  "#[.AppName]#/src/workers"
)

func init() {
	//注册CLI方法 (Action 结尾)
	x.AddCli(&TestCliController{})
}

type TestCliController struct {
	controller.Controller
}

func (this *TestCliController) HelloAction() { // {{{

	msg := this.GetString("msg")

	x.Interceptor(len(msg) > 0, x.ERR_PARAMS, "msg")

	ret := map[string]interface{}{
		"msg": msg,
	}

	this.Render(ret)

} // }}}

func (this *TestCliController) QueueAction() { // {{{

	//queue := nyxqueue.NewNyxQueue()
	//queue.SetDebug(this.Debug)
	//queue.AddWorker("test", &workers.TestWorker{}, nyxqueue.WithWorkerOptionChildren(1))

	//queue.Run()
} // }}}

package cli

type TestController struct {
	BaseController
}

func (t *TestController) HelloAction() {
	t.Println("hello world!")
}

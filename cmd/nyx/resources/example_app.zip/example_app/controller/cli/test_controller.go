package cli

type TestController struct {
	BaseController
}

func (this *TestController) HelloAction() {
	this.Println("hello world!")
}

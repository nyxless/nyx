package cli

import (
	"github.com/nyxless/nyx/controller"
)

type BaseController struct {
	controller.CLI
}

func (this *BaseController) Init() {
	this.Println("cli init...")
}

package cli

import (
	"github.com/nyxless/nyx/controller"
)

type BaseController struct {
	controller.CLI
}

func (b BaseController) Init() {
	b.Println("cli init...")
}

package rpc

import (
	"github.com/nyxless/nyx/controller"
)

type BaseController struct {
	controller.RPC
}

func (b *BaseController) Init() { // {{{
	b.Println("base init")
} // }}}

func (b *BaseController) Final() { // {{{
	b.Println("base final")
} // }}}

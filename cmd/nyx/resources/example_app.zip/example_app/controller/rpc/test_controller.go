package rpc

import (
	"github.com/nyxless/nyx/x"
	"time"
)

type TestController struct {
	BaseController
}

func (this *TestController) HelloAction() { // {{{

	msg := this.GetString("msg")

	x.Interceptor(len(msg) > 0, x.ERR_PARAMS, "msg")

	ret := map[string]interface{}{
		"msg":         msg,
		"header-guid": this.GetHeader("guid"),
		"testmap": x.MAP{
			"a": 1,
			"b": "2",
			"c": []int{1, 23, 4},
		},
		"testbytes": []byte("test bytes ..... "),
		"time":      x.Now(),
	}

	this.SetHeader("test-header", "some data")

	this.Render(ret)

} // }}}

func (this *TestController) StreamAction() { // {{{

	msg := this.GetString("msg")

	x.Interceptor(len(msg) > 0, x.ERR_PARAMS, "msg")

	for i := 0; i < 5; i++ {
		ret := map[string]interface{}{
			"i":           i,
			"msg":         msg,
			"header-guid": this.GetHeader("guid"),
			"testmap": x.MAP{
				"a": 1,
				"b": "2",
				"c": []int{1, 23, 4},
			},
			"testbytes": []byte("test bytes ..... "),
			"time":      x.Now(),
		}

		this.SetHeader("test-header", x.AsString(i))

		this.RenderStream(ret)
		time.Sleep(1e9)
	}

} // }}}

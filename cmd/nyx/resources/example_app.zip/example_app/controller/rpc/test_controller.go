package rpc

import (
	"github.com/nyxless/nyx/x"
	"time"
)

type TestController struct {
	BaseController
}

func (t *TestController) HelloAction() { // {{{

	msg := t.GetString("msg")

	x.Interceptor(len(msg) > 0, x.ErrParams, "msg")

	ret := map[string]interface{}{
		"msg":         msg,
		"header-guid": t.GetHeader("guid"),
		"testmap": x.MAP{
			"a": 1,
			"b": "2",
			"c": []int{1, 23, 4},
		},
		"testbytes": []byte("test bytes ..... "),
		"time":      x.Now(),
	}

	t.SetHeader("test-header", "some data")

	t.Render(ret)

} // }}}

func (t *TestController) StreamAction() { // {{{

	msg := t.GetString("msg")

	x.Interceptor(len(msg) > 0, x.ErrParams, "msg")

	for i := 0; i < 5; i++ {
		ret := map[string]interface{}{
			"i":           i,
			"msg":         msg,
			"header-guid": t.GetHeader("guid"),
			"testmap": x.MAP{
				"a": 1,
				"b": "2",
				"c": []int{1, 23, 4},
			},
			"testbytes": []byte("test bytes ..... "),
			"time":      x.Now(),
		}

		t.SetHeader("test-header", x.AsString(i))

		t.RenderStream(ret)
		time.Sleep(1e9)
	}

} // }}}

package controller

import (
	"github.com/nyxless/nyx/controller"
	"github.com/nyxless/nyx/x"
	//"time"
)

type IndexController struct {
	controller.Controller
}

func init() {
	//注册http api 方法 (Action 结尾)
	x.AddApi(&IndexController{})
}

func (this *IndexController) Init() {
	// this.Println("index init")
}

func (this *IndexController) IndexAction() { // {{{

	this.RenderText("hello world!")
	//this.RenderJson(x.MAP{"hello": "world"})

} // }}}

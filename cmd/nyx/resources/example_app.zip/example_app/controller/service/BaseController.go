package service

import (
	//	"context"
	"github.com/nyxless/nyx/controller"
	//	"github.com/nyxless/nyx/x"
)

type BaseController struct {
	controller.Controller
}

func (this *TestRpcController) Init() { // {{{

	//ctx := context.WithValue(this.Ctx, "traceid", this.GetParam("traceid"))
	//	x.Logger.WithContext(ctx)
	//this.Println(this.Ctx)

} // }}}

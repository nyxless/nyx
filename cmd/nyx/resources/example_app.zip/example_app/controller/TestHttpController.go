package controller

import (
	"#[.AppName]#/model"
	"github.com/nyxless/nyx/controller"
	"github.com/nyxless/nyx/x"
	//"time"
)

type TestHttpController struct {
	controller.Controller
}

func init() {
	//注册http api 方法 (Action 结尾)
	x.AddApi(&TestHttpController{})
}

func (this *TestHttpController) HelloAction() { // {{{

	// 参数接收
	uid := this.GetInt("uid")
	msg := this.GetString("msg")

	// 参数拦截器
	x.Interceptor(uid > 0, x.ERR_PARAMS, "err uid")
	x.Interceptor(len(msg) > 0, "only err msg")

	// 业务逻辑
	user_info := model.User().GetUserInfo(uid)

	// 返回数据
	ret := x.MAP{
		"user_info": user_info,
		"msg":       msg,
	}

	this.Render(ret)

} // }}}

func (this *TestHttpController) GetUserInfoAction() { // {{{

	uid := this.GetInt("uid")

	x.Interceptor(uid > 0, x.ERR_PARAMS, "uid")

	user_info := model.User().GetUserInfo(uid)

	ret := x.MAP{
		"user_info": user_info,
	}
	//time.Sleep(10e9)

	this.Render(ret)

} // }}}

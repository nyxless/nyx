package main

import (
	_ "#[.AppName]#/autoload"
	"github.com/nyxless/nyx"
	//"github.com/nyxless/nyx/x"
)

func main() {
	//初始化本地缓存
	//x.LocalCache = x.NewLocalCache()

	//设置TCP服务的回调
	//x.SetTcpHandler(h)

	//设置Websocket服务的回调
	//x.SetWebsocketHandler("/", wh)

	//按模式启动, 同时启用多个逗号分隔: ./run http,tcp,ws,rpc,cli
	//也可以访问独立方法启动,如: RunRpc()
	nyx.NewNyx().Run()
}

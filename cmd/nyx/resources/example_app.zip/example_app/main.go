package main

import (
	"github.com/nyxless/nyx"
	_ "your_module_name/autoload"
)

func main() {
	n := nyx.NewNyx()
	n.Run()
}

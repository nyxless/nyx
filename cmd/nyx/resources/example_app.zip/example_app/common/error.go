package common

import (
	"github.com/nyxless/nyx/x"
)

var (
	ERR_TOKEN    = x.NewErr(106, "CN", "认证失败", "EN", "token is invalid")
	ERR_PASSWORD = x.NewErr(107, "CN", "密码错误", "EN", "password is invalid")
)

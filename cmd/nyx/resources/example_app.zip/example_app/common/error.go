package common

import (
	"github.com/nyxless/nyx/x"
)

var (
	ERR_TOKEN = x.NewErr(101, "CN", "认证失败", "EN", "token is invalid")
)

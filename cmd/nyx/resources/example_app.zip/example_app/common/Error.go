package common

import (
	"github.com/nyxless/nyx/x"
)

var (
	ERR_TEST = &x.Error{1001, "just a test: %v"}
)

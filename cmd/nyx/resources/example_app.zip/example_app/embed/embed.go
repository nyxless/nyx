package embed

/*
* 使用嵌入式 模板、静态文件
* 在 main.go 中 引入:   _ "your_module_name/embed"
 */
import (
	"embed"
	"github.com/nyxless/nyx/x"
)

//go:embed templates static
var embedFS embed.FS

func init() {
	x.TemplateEmbed(embedFS, "templates")
	x.StaticEmbed(embedFS, "static")
}

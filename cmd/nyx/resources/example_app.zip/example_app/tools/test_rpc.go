package main

import (
	"context"
	"fmt"
	"time"

	"github.com/nyxless/nyxc"
	"github.com/nyxless/nyxc/rpc"
)

var path = "test/hello"
var pathStream = "test/stream"

func main() {

	address := "localhost:8081"
	appid := "1000"
	secret := "test"

	// 创建客户端，可以添加多个选项
	client, err := nyxc.NewNyxClient(
		address,
		appid,
		secret,
		nyxc.UseCache(200*1024*1024), // 启用200M缓存
		nyxc.WithMaxIdleConns(5),
		nyxc.WithMaxOpenConns(1000),
		nyxc.Debug(), // 开启调试模式
		// nyxc.WithAuthFn(customAuthFn), // 如果需要自定义鉴权函数
	)

	if err != nil {
		panic(fmt.Sprintf("创建客户端失败: %v", err))
	}

	// 确保程序退出时关闭客户端
	defer client.Close()

	// 同步请求示例
	syncExample(client)

	// 带缓存的请求示例
	cacheExample(client)

	// 流式请求示例
	streamExample(client)

	// 带自定义上下文的请求
	contextExample(client)

	// 带自定义Header的请求
	headerExample(client)
}

// 同步请求示例
func syncExample(client *nyxc.NyxClient) {
	fmt.Println("=== 同步请求示例 ===")

	type UserRequest struct {
		UserID int      `json:"user_id"`
		Name   string   `json:"name"`
		Age    int      `json:"age"`
		Tags   []string `json:"tags"`
	}

	userReq := UserRequest{
		UserID: 12345,
		Name:   "李四",
		Age:    30,
		Tags:   []string{"java", "frontend"},
	}

	// 发送请求，可以添加多个CallOption
	resp, err := client.Request(
		path,
		userReq,
		nyxc.WithTimeout(5*time.Second), // 设置5秒超时
		// nyxc.WithHeaders(map[string]string{"X-Trace-ID": "abc123"}), // 添加自定义Header
	)

	if err != nil {
		fmt.Printf("请求失败: %v\n", err)
		return
	}

	// 检查响应码
	if resp.GetCode() != 0 {
		fmt.Printf("业务错误: code=%d, msg=%s\n", resp.GetCode(), resp.GetMsg())
		return
	}

	// 获取响应数据
	var result map[string]interface{}
	result = resp.GetData()

	fmt.Printf("请求成功: %v\n", result)
	fmt.Printf("响应Header: %v\n", resp.GetHeaders())
}

// 带缓存的请求示例
func cacheExample(client *nyxc.NyxClient) {
	fmt.Println("\n=== 带缓存的请求示例 ===")

	params := map[string]interface{}{
		"msg": "request-msg",
	}

	// 缓存回调函数，用于处理缓存数据
	cacheCallback := func(data map[string]any) error {
		fmt.Printf("从缓存获取到数据: %#v\n", data)
		return nil
	}

	// 使用WithCache，缓存30秒
	resp, err := client.Request(
		path,
		params,
		nyxc.WithCache(30, cacheCallback), // 缓存30秒
		nyxc.WithTimeout(3*time.Second),
	)

	if err != nil {
		fmt.Printf("请求失败: %v\n", err)
		return
	}

	// 检查是否命中缓存
	if t, ok := resp.GetCacheTime(); ok {
		fmt.Println("✅ 命中缓存")
		fmt.Printf("缓存时间: %v\n", t)
	} else {
		fmt.Println("❌ 未命中缓存，从服务端获取")
	}

	// 另一种缓存方式：定期刷新缓存
	resp2, err := client.Request(
		path,
		nil,
		nyxc.WithRefreshCache(60, cacheCallback), // 每60秒刷新一次缓存
	)

	if err != nil {
		fmt.Printf("定期刷新缓存请求失败: %v\n", err)
		return
	}

	fmt.Printf("定期刷新缓存请求成功: code=%d\n", resp2.GetCode())
}

// 流式请求示例
func streamExample(client *nyxc.NyxClient) {
	fmt.Println("\n=== 流式请求示例 ===")

	params := map[string]interface{}{
		"msg": "request-msg",
	}

	// 获取流式响应
	iter, err := client.RequestStream(
		pathStream,
		params,
		nyxc.WithTimeout(30*time.Second), // 流式请求超时时间可以设置长一些
	)

	if err != nil {
		fmt.Printf("创建流式请求失败: %v\n", err)
		return
	}

	// 遍历流式响应
	err = iter.Foreach(func(res *rpc.Response) error {
		if code := res.GetCode(); code > 0 {
			return fmt.Errorf(res.GetMsg())
		}

		data := res.GetData()
		fmt.Printf("收到流数据: %#v\n", data)
		return nil
	})

	if err != nil {
		fmt.Printf("流数据出错: %#v\n", err)
	}
}

// 带自定义上下文的请求
func contextExample(client *nyxc.NyxClient) {
	fmt.Println("\n=== 带自定义上下文的请求 ===")

	// 创建自定义上下文，可以传递trace信息等
	ctx := context.WithValue(context.Background(), "guid", "trace-123456789")
	ctx = context.WithValue(ctx, "user_ip", "192.168.1.100")

	params := map[string]interface{}{
		"msg": "request-msg",
	}

	resp, err := client.Request(
		path,
		params,
		nyxc.WithContext(ctx),
		nyxc.WithTimeout(10*time.Second),
	)

	if err != nil {
		fmt.Printf("请求失败: %v\n", err)
		return
	}

	fmt.Printf("带上下文请求成功: code=%d\n", resp.GetCode())
}

// 带自定义Header的请求
func headerExample(client *nyxc.NyxClient) {
	fmt.Println("\n=== 带自定义Header的请求 ===")

	// 自定义Header
	customHeaders := map[string]string{
		"X-Trace-ID":       "trace-987654321",
		"X-Request-ID":     "req-20230101-001",
		"X-Client-Version": "1.0.0",
		"X-User-Agent":     "MyCustomClient/1.0",
	}

	params := map[string]interface{}{
		"msg": "request-msg",
	}

	resp, err := client.Request(
		path,
		params,
		nyxc.WithHeaders(customHeaders),
		nyxc.WithTimeout(3*time.Second),
	)

	if err != nil {
		fmt.Printf("请求失败: %v\n", err)
		return
	}

	fmt.Printf("带自定义Header请求成功\n")
	fmt.Printf("响应Header: %v\n", resp.GetHeaders())
	fmt.Printf("响应Trailer: %v\n", resp.GetTrailers())
}

// 自定义鉴权函数示例
func customAuthFn(appid, secret string) map[string]string {
	// 这里可以实现自定义的鉴权算法
	// 例如：生成签名、token等

	timestamp := time.Now().Unix()
	// 假设这里有一个签名算法
	// sign := generateSignature(appid, secret, timestamp)

	return map[string]string{
		"Appid":     appid,
		"Timestamp": fmt.Sprintf("%d", timestamp),
		// "Sign":      sign,
		"Custom-Auth": "v2", // 自定义鉴权版本
	}
}

// 错误处理示例

// 批量请求示例
func batchExample(client *nyxc.NyxClient) {
	fmt.Println("\n=== 批量请求示例 ===")

	// 可以并发发送多个请求
	results := make(chan string, 3)

	// 并发请求1
	go func() {
		resp, err := client.Request(path, nil)
		if err != nil {
			results <- fmt.Sprintf("请求1失败: %v", err)
			return
		}
		results <- fmt.Sprintf("请求1成功: code=%d", resp.GetCode())
	}()

	// 并发请求2
	go func() {
		resp, err := client.Request(path, nil)
		if err != nil {
			results <- fmt.Sprintf("请求2失败: %v", err)
			return
		}
		results <- fmt.Sprintf("请求2成功: code=%d", resp.GetCode())
	}()

	// 并发请求3
	go func() {
		resp, err := client.Request(path, nil)
		if err != nil {
			results <- fmt.Sprintf("请求3失败: %v", err)
			return
		}
		results <- fmt.Sprintf("请求3成功: code=%d", resp.GetCode())
	}()

	// 收集结果
	for i := 0; i < 3; i++ {
		result := <-results
		fmt.Println(result)
	}
}

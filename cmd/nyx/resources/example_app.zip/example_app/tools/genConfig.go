package main

import (
	"fmt"
	"gopkg.in/yaml.v3"
	"log"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"unicode"
)

type TypeInfo struct {
	Name      string
	Fields    []FieldInfo
	IsArray   bool
	ArrayElem *TypeInfo
	Used      bool // 标记是否已使用，避免重复生成
}

type FieldInfo struct {
	Name     string
	Type     string
	YAMLTag  string
	Children *TypeInfo
}

var (
	invalidIdentifierChars = regexp.MustCompile(`[^a-zA-Z0-9_]`)
	definedTypes           = make(map[string]*TypeInfo) // 记录已定义的类型
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: go run main.go <yaml-file>")
		os.Exit(1)
	}

	yamlFile := os.Args[1]
	data, err := os.ReadFile(yamlFile)
	if err != nil {
		log.Fatalf("Error reading YAML file: %v", err)
	}

	var config interface{}
	if err := yaml.Unmarshal(data, &config); err != nil {
		log.Fatalf("Error parsing YAML: %v", err)
	}

	baseName := filepath.Base(yamlFile)
	typeName := sanitizeTypeName(baseName)
	if typeName == "" {
		typeName = "Config"
	}

	rootType := analyzeType(typeName, config)
	code := generateGoCode(rootType)
	fmt.Println(code)
}

func sanitizeTypeName(name string) string { // {{{
	name = strings.TrimSuffix(name, ".yaml")
	name = strings.TrimSuffix(name, ".yml")
	name = invalidIdentifierChars.ReplaceAllString(name, "_")

	// 处理连续下划线
	name = strings.ReplaceAll(name, "__", "_")
	name = strings.Trim(name, "_")

	if len(name) == 0 {
		return ""
	}

	// 确保不以数字开头
	if unicode.IsDigit(rune(name[0])) {
		name = "_" + name
	}

	return capitalize(name)
} // }}}

func capitalize(s string) string {
	if s == "" {
		return s
	}
	r := []rune(s)
	r[0] = unicode.ToUpper(r[0])
	return string(r)
}

func sanitizeFieldName(s string) string {
	s = invalidIdentifierChars.ReplaceAllString(s, "_")
	s = strings.Trim(s, "_")
	if s == "" {
		return "Field"
	}
	return capitalize(s)
}

func analyzeType(typeName string, data interface{}) *TypeInfo {
	// 检查是否已分析过该类型
	if typ, exists := definedTypes[typeName]; exists {
		return typ
	}

	info := &TypeInfo{Name: typeName}
	definedTypes[typeName] = info

	switch v := data.(type) {
	case map[string]interface{}:
		for key, value := range v {
			fieldName := sanitizeFieldName(key)
			fieldType, children := determineTypeAndChildren(fieldName, value)

			info.Fields = append(info.Fields, FieldInfo{
				Name:     fieldName,
				Type:     fieldType,
				YAMLTag:  key,
				Children: children,
			})
		}

	case []interface{}:
		info.IsArray = true
		if len(v) > 0 {
			info.ArrayElem = analyzeType(typeName+"Elem", v[0])
		} else {
			// 空数组默认使用interface{}类型
			info.ArrayElem = &TypeInfo{Name: "interface{}"}
		}
	}

	return info
}

func determineTypeAndChildren(fieldName string, data interface{}) (string, *TypeInfo) {
	switch v := data.(type) {
	case string:
		return "string", nil
	case bool:
		return "bool", nil
	case int:
		return "int", nil
	case int8:
		return "int", nil
	case int16:
		return "int", nil
	case int32:
		return "int", nil
	case int64:
		return "int", nil
	case float32:
		f := float64(v)
		if f == float64(int(f)) {
			return "int", nil
		}
		return "float64", nil
	case float64:
		f := v
		if f == float64(int(f)) {
			return "int", nil
		}
		return "float64", nil
	case []interface{}:
		if len(v) == 0 {
			return "[]interface{}", nil
		}
		elemType, children := determineTypeAndChildren(fieldName, v[0])
		return "[]" + elemType, children

	case map[string]interface{}:
		// 为嵌套结构生成类型名称
		structName := fieldName
		if _, exists := definedTypes[structName]; exists {
			// 如果已存在，添加后缀避免冲突
			i := 1
			for {
				newName := fmt.Sprintf("%s%d", structName, i)
				if _, exists := definedTypes[newName]; !exists {
					structName = newName
					break
				}
				i++
			}
		}
		return structName, analyzeType(structName, v)

	default:
		return "interface{}", nil
	}
}

func generateGoCode(typeInfo *TypeInfo) string {
	var builder strings.Builder

	// 避免重复生成相同类型
	if typeInfo.Used {
		return ""
	}
	typeInfo.Used = true

	if typeInfo.IsArray {
		builder.WriteString(fmt.Sprintf("type %s []%s\n\n", typeInfo.Name, typeInfo.ArrayElem.Name))
		if typeInfo.ArrayElem.Fields != nil {
			builder.WriteString(generateGoCode(typeInfo.ArrayElem))
		}
	} else if len(typeInfo.Fields) > 0 || typeInfo.Name == "interface{}" {
		// 只有具有字段或者是interface{}类型时才生成定义
		builder.WriteString(fmt.Sprintf("type %s struct {\n", typeInfo.Name))
		for _, field := range typeInfo.Fields {
			builder.WriteString(fmt.Sprintf("\t%s %s `yaml:\"%s\"`\n",
				field.Name, field.Type, field.YAMLTag))
		}
		builder.WriteString("}\n\n")

		// 生成嵌套类型
		for _, field := range typeInfo.Fields {
			if field.Children != nil {
				builder.WriteString(generateGoCode(field.Children))
			}
		}
	}

	return builder.String()
}

package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"gopkg.in/yaml.v3"
)

// Loader 配置加载器
type Loader struct {
	baseDirs    []string        // 配置搜索路径
	loadedFiles map[string]bool // 已加载文件记录
	allowCycles bool            // 是否允许循环引用
}

// Option 加载器选项类型
type Option func(*Loader)

// NewLoader 创建新加载器
func NewLoader(options ...Option) *Loader {
	l := &Loader{
		loadedFiles: make(map[string]bool),
		baseDirs:    []string{"."}, // 默认当前目录
	}
	for _, opt := range options {
		opt(l)
	}
	return l
}

// WithBaseDirs 设置配置搜索路径
func WithBaseDirs(dirs ...string) Option {
	return func(l *Loader) {
		l.baseDirs = dirs
	}
}

// WithCycleDetection 启用/禁用循环引用检测
func WithCycleDetection(enabled bool) Option {
	return func(l *Loader) {
		l.allowCycles = !enabled
	}
}

// Load 加载配置文件
func (l *Loader) Load(filename string, out interface{}) error {
	l.loadedFiles = make(map[string]bool)
	mainNode, err := l.loadFile(filename)
	if err != nil {
		return fmt.Errorf("failed to load config: %w", err)
	}
	return mainNode.Decode(out)
}

// loadFile 加载单个文件并处理include
func (l *Loader) loadFile(filename string) (*yaml.Node, error) {
	fullPath, err := l.findFile(filename)
	if err != nil {
		return nil, err
	}

	// 检查循环引用
	if !l.allowCycles && l.loadedFiles[fullPath] {
		return nil, fmt.Errorf("circular reference detected: %s", fullPath)
	}
	l.loadedFiles[fullPath] = true

	data, err := os.ReadFile(fullPath)
	if err != nil {
		return nil, err
	}

	var node yaml.Node
	if err := yaml.Unmarshal(data, &node); err != nil {
		return nil, fmt.Errorf("failed to parse %s: %w", fullPath, err)
	}

	if len(node.Content) > 0 {
		if err := l.processIncludes(node.Content[0], filepath.Dir(fullPath)); err != nil {
			return nil, err
		}
	}

	return &node, nil
}

// processIncludes 递归处理include指令
func (l *Loader) processIncludes(node *yaml.Node, baseDir string) error {
	// 处理include指令
	if node.Kind == yaml.ScalarNode && node.Tag == "!include" {
		includedNode, err := l.loadFile(filepath.Join(baseDir, node.Value))
		if err != nil {
			return err
		}
		*node = *includedNode.Content[0]
		return nil
	}

	// 递归处理子节点
	for i := 0; i < len(node.Content); i++ {
		child := node.Content[i]

		// 映射节点的值节点在奇数索引
		if node.Kind == yaml.MappingNode && i%2 == 1 {
			if err := l.processIncludes(child, baseDir); err != nil {
				return err
			}
			continue
		}

		if err := l.processIncludes(child, baseDir); err != nil {
			return err
		}
	}

	return nil
}

// findFile 在搜索路径中查找文件
func (l *Loader) findFile(filename string) (string, error) {
	// 尝试绝对路径或显式相对路径
	if filepath.IsAbs(filename) || strings.HasPrefix(filename, ".") {
		if _, err := os.Stat(filename); err == nil {
			return filename, nil
		}
	}

	// 在基础目录中查找
	for _, dir := range l.baseDirs {
		fullPath := filepath.Join(dir, filename)
		if _, err := os.Stat(fullPath); err == nil {
			return fullPath, nil
		}
	}

	return "", fmt.Errorf("file not found: %s (searched in %v)", filename, l.baseDirs)
}

// 配置结构体定义
type DatabaseConfig struct {
	Host     string `yaml:"host"`
	Port     int    `yaml:"port"`
	Username string `yaml:"username"`
	Password string `yaml:"password"`
}

type ServiceConfig struct {
	Endpoint string `yaml:"endpoint"`
	Timeout  int    `yaml:"timeout"`
}

type AppConfig struct {
	Base     interface{}              `yaml:"base"` // 基础配置可以是非结构化数据
	Database DatabaseConfig           `yaml:"database"`
	Services map[string]ServiceConfig `yaml:"services"`
	Logging  struct {
		Level    string `yaml:"level"`
		FilePath string `yaml:"file_path"`
	} `yaml:"logging"`
}

func main() {
	// 获取可执行文件所在目录作为默认配置路径
	exeDir, _ := os.Executable()
	configDir := filepath.Join(filepath.Dir(exeDir), "config")

	loader := NewLoader(
		WithBaseDirs(".", configDir, "./conf"),
		WithCycleDetection(true),
	)

	var cfg AppConfig
	if err := loader.Load("app.conf", &cfg); err != nil {
		fmt.Printf("Failed to load config: %v\n", err)
		os.Exit(1)
	}

	fmt.Printf("Loaded config: %+v\n", cfg)
}

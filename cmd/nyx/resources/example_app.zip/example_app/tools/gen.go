package main

import (
	"fmt"
	"go/format"
	"strings"

	"gopkg.in/yaml.v3"
)

type StructGenerator struct {
	PackageName string
	TypeName    string
}

func NewGenerator(pkg, typeName string) *StructGenerator {
	return &StructGenerator{
		PackageName: pkg,
		TypeName:    typeName,
	}
}

func (g *StructGenerator) GenerateFromYAML(yamlContent []byte) ([]byte, error) {
	var data interface{}
	if err := yaml.Unmarshal(yamlContent, &data); err != nil {
		return nil, fmt.Errorf("yaml unmarshal failed: %w", err)
	}

	structDef := g.generateStruct(g.TypeName, data)
	sourceCode := fmt.Sprintf(`package %s

%s`, g.PackageName, structDef)

	formatted, err := format.Source([]byte(sourceCode))
	if err != nil {
		return nil, fmt.Errorf("go format failed: %w", err)
	}

	return formatted, nil
}

func (g *StructGenerator) generateStruct(name string, data interface{}) string {
	switch v := data.(type) {
	case map[string]interface{}:
		return g.generateFromMap(name, v)
	case []interface{}:
		return g.generateFromSlice(name, v)
	default:
		return fmt.Sprintf("type %s %T\n", name, v)
	}
}

func (g *StructGenerator) generateFromMap(name string, data map[string]interface{}) string {
	var builder strings.Builder
	builder.WriteString(fmt.Sprintf("type %s struct {\n", name))

	for key, val := range data {
		fieldName := strings.Title(key)
		fieldType := g.determineType(key, val)
		builder.WriteString(fmt.Sprintf("\t%s %s `yaml:\"%s\"`\n", fieldName, fieldType, key))
	}

	builder.WriteString("}\n")

	// Generate nested types
	for key, val := range data {
		if nestedMap, ok := val.(map[string]interface{}); ok {
			builder.WriteString(g.generateFromMap(key, nestedMap))
		} else if nestedSlice, ok := val.([]interface{}); ok && len(nestedSlice) > 0 {
			if _, isSimple := nestedSlice[0].(map[string]interface{}); isSimple {
				builder.WriteString(g.generateFromSlice(key, nestedSlice))
			}
		}
	}

	return builder.String()
}

func (g *StructGenerator) generateFromSlice(name string, data []interface{}) string {
	if len(data) == 0 {
		return fmt.Sprintf("type %s []interface{}\n", name)
	}

	// Check if it's a slice of objects
	if first, ok := data[0].(map[string]interface{}); ok {
		structDef := g.generateFromMap(name+"Item", first)
		return structDef + fmt.Sprintf("type %s []%sItem\n", name, name)
	}

	// For simple type slices
	elemType := g.determineType("", data[0])
	return fmt.Sprintf("type %s []%s\n", name, elemType)
}

func (g *StructGenerator) determineType(key string, val interface{}) string {
	switch v := val.(type) {
	case map[string]interface{}:
		return strings.Title(key)
	case []interface{}:
		if len(v) == 0 {
			return "[]interface{}"
		}
		return "[]" + g.determineType(key, v[0])
	case float64:
		if v == float64(int(v)) {
			return "int"
		}
		return "float64"
	case int:
		return "int"
	case string:
		return "string"
	case bool:
		return "bool"
	default:
		return "interface{}"
	}
}

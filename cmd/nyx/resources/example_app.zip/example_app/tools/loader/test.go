package main

import (
	"fmt"
	"gopkg.in/yaml.v3"
	"log"
	"os"
	"path/filepath"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Usage: genstruct <config.yaml> [output.go]")
		os.Exit(1)
	}

	inputFile := os.Args[1]
	outputFile := "config_gen.go"
	if len(os.Args) > 2 {
		outputFile = os.Args[2]
	}

	// 1. 加载配置（处理所有includes）
	cfgLoader := NewLoader()

	var fullConfig interface{}
	if err := cfgLoader.Load(inputFile, &fullConfig); err != nil {
		log.Fatalf("Config loading failed: %v", err)
	}

	fmt.Println(fullConfig)
	return

	// 2. 将完整配置转回YAML（用于生成）
	yamlData, err := yaml.Marshal(fullConfig)
	if err != nil {
		log.Fatalf("YAML marshal failed: %v", err)
	}

	// 3. 生成结构体
	pkgName := filepath.Base(filepath.Dir(outputFile))
	if pkgName == "." {
		pkgName = "config"
	}

	gen := NewGenerator(pkgName, "Config")
	goCode, err := gen.GenerateFromYAML(yamlData)
	if err != nil {
		log.Fatalf("Code generation failed: %v", err)
	}

	// 4. 输出结果
	if err := os.WriteFile(outputFile, goCode, 0644); err != nil {
		log.Fatalf("Failed to write output: %v", err)
	}

	fmt.Printf("Successfully generated %s\n", outputFile)
}

package config

type Config struct {
	Http_port          int                `yaml:"http_port"`
	Http_timeout       int                `yaml:"http_timeout"`
	Tcp_port           int                `yaml:"tcp_port"`
	Ws_timeout         int                `yaml:"ws_timeout"`
	App_pid_file       string             `yaml:"app_pid_file"`
	Check_freq         bool               `yaml:"check_freq"`
	Freq_conf          Freq_conf          `yaml:"freq_conf"`
	Log_name           string             `yaml:"log_name"`
	Log_root           string             `yaml:"log_root"`
	Monitor_port       int                `yaml:"monitor_port"`
	Rpc_port           int                `yaml:"rpc_port"`
	Ws_addr            interface{}        `yaml:"ws_addr"`
	Ws_port            int                `yaml:"ws_port"`
	Freq_redis         Freq_redis         `yaml:"freq_redis"`
	Log_level          int                `yaml:"log_level"`
	Pprof_enable       bool               `yaml:"pprof_enable"`
	Rpc_addr           interface{}        `yaml:"rpc_addr"`
	Rpc_auth           Rpc_auth           `yaml:"rpc_auth"`
	Rpc_client_message Rpc_client_message `yaml:"rpc_client_message"`
	Tcp_addr           interface{}        `yaml:"tcp_addr"`
	Http_addr          interface{}        `yaml:"http_addr"`
}
type freq_redis struct {
	Host     string `yaml:"host"`
	Password string `yaml:"password"`
	Poolsize int    `yaml:"poolsize"`
	Timeout  int    `yaml:"timeout"`
}
type rpc_auth struct {
	Test string `yaml:"test"`
}
type rpc_client_message struct {
	Secret string `yaml:"secret"`
	Appid  string `yaml:"appid"`
	Host   string `yaml:"host"`
}
type freq_conf struct {
	Testhttp_hello []Testhttp_hello `yaml:"testhttp_hello"`
}
type testhttp_helloItem struct {
	Blacklist int    `yaml:"blacklist"`
	Freq      int    `yaml:"freq"`
	Interval  int    `yaml:"interval"`
	Key       string `yaml:"key"`
	Whitelist int    `yaml:"whitelist"`
}
type testhttp_hello []testhttp_helloItem

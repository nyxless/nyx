package main

import (
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"
	"regexp"

	"gopkg.in/yaml.v3"
)

// 预处理 YAML 内容，处理 include 指令
func preprocessYAML(input string, baseDir string) (string, error) {
	// 匹配 !include 指令的正则表达式
	includeRegex := regexp.MustCompile(`!include\s+(?:'([^']+)'|"([^"]+)"|([^\s]+))`)

	// 替换函数
	replaceFunc := func(match string) string {
		// 提取文件名
		var filename string
		if groups := includeRegex.FindStringSubmatch(match); len(groups) >= 4 {
			if groups[1] != "" {
				filename = groups[1]
			} else if groups[2] != "" {
				filename = groups[2]
			} else {
				filename = groups[3]
			}
		}

		// 处理相对路径
		if !filepath.IsAbs(filename) {
			filename = filepath.Join(baseDir, filename)
		}

		// 读取被包含的文件内容
		content, err := ioutil.ReadFile(filename)
		if err != nil {
			return fmt.Sprintf("!!error '%s'", err.Error())
		}

		// 递归处理嵌套的 include
		processed, err := preprocessYAML(string(content), filepath.Dir(filename))
		if err != nil {
			return fmt.Sprintf("!!error '%s'", err.Error())
		}

		return processed
	}

	// 替换所有 include 指令
	output := includeRegex.ReplaceAllStringFunc(input, replaceFunc)
	return output, nil
}

// 加载 YAML 文件并处理 include
func LoadYAMLWithInclude(filename string, out interface{}) error {
	// 读取文件内容
	content, err := ioutil.ReadFile(filename)
	if err != nil {
		return err
	}

	// 预处理 include
	processed, err := preprocessYAML(string(content), filepath.Dir(filename))
	if err != nil {
		return err
	}
	// 解析 YAML
	return yaml.Unmarshal([]byte(processed), out)
}

func main() {
	inputFile := os.Args[1]
	// 示例用法
	var config map[string]interface{}
	err := LoadYAMLWithInclude(inputFile, &config)
	if err != nil {
		fmt.Printf("Error loading YAML: %v\n", err)
		os.Exit(1)
	}

	// 使用解析后的配置...
	fmt.Printf("Loaded config: %+v\n", config)
}

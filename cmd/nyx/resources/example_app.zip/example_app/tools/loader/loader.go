package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"gopkg.in/yaml.v3"
)

type Loader struct {
	baseDirs    []string
	loadedFiles map[string]bool
	options     LoaderOptions
	fileCache   map[string]*yaml.Node
}

type LoaderOptions struct {
	AllowCycles     bool
	MaxIncludeDepth int
	EnableCache     bool
}

func NewLoader(opts ...LoaderOption) *Loader {
	l := &Loader{
		baseDirs:    []string{"."},
		loadedFiles: make(map[string]bool),
		fileCache:   make(map[string]*yaml.Node),
		options: LoaderOptions{
			MaxIncludeDepth: 10,
			EnableCache:     true,
		},
	}
	for _, opt := range opts {
		opt(&l.options)
	}
	return l
}

type LoaderOption func(*LoaderOptions)

func WithMaxIncludeDepth(depth int) LoaderOption {
	return func(o *LoaderOptions) {
		o.MaxIncludeDepth = depth
	}
}

func WithCache(enabled bool) LoaderOption {
	return func(o *LoaderOptions) {
		o.EnableCache = enabled
	}
}

func (l *Loader) Load(filename string, out interface{}) error {
	l.loadedFiles = make(map[string]bool)
	if l.options.EnableCache {
		l.fileCache = make(map[string]*yaml.Node)
	}

	fullPath, err := l.findFile(filename)
	if err != nil {
		return fmt.Errorf("file not found: %w", err)
	}

	rootNode, err := l.loadFile(fullPath, 0)
	if err != nil {
		return fmt.Errorf("load failed: %w", err)
	}

	// Handle root-level !include
	if isStandaloneInclude(rootNode) {
		includedNode, err := l.loadFile(filepath.Join(filepath.Dir(fullPath), rootNode.Content[0].Value), 1)
		if err != nil {
			return fmt.Errorf("root include failed: %w", err)
		}
		rootNode = includedNode
	} else {
		if err := l.processIncludes(rootNode, filepath.Dir(fullPath), 0); err != nil {
			return fmt.Errorf("process includes failed: %w", err)
		}
	}

	return rootNode.Decode(out)
}

func isStandaloneInclude(node *yaml.Node) bool {
	return len(node.Content) == 1 &&
		node.Content[0].Kind == yaml.ScalarNode &&
		node.Content[0].Tag == "!include"
}

func (l *Loader) loadFile(filename string, depth int) (*yaml.Node, error) {
	if depth > l.options.MaxIncludeDepth {
		return nil, fmt.Errorf("max include depth %d exceeded", l.options.MaxIncludeDepth)
	}

	fullPath, err := l.findFile(filename)
	if err != nil {
		return nil, err
	}

	if !l.options.AllowCycles {
		if _, loaded := l.loadedFiles[fullPath]; loaded {
			return nil, fmt.Errorf("circular reference detected: %s", fullPath)
		}
		l.loadedFiles[fullPath] = true
	}

	if l.options.EnableCache {
		if cached, ok := l.fileCache[fullPath]; ok {
			return cached, nil
		}
	}

	data, err := os.ReadFile(fullPath)
	if err != nil {
		return nil, fmt.Errorf("read file failed: %w", err)
	}

	var node yaml.Node
	if err := yaml.Unmarshal(data, &node); err != nil {
		return nil, fmt.Errorf("yaml unmarshal failed: %w", err)
	}

	if l.options.EnableCache {
		l.fileCache[fullPath] = &node
	}

	return &node, nil
}

func (l *Loader) processIncludes(node *yaml.Node, baseDir string, depth int) error {
	// Handle standalone include in mapping values
	if node.Kind == yaml.ScalarNode && node.Tag == "!include" {
		includedNode, err := l.loadFile(filepath.Join(baseDir, node.Value), depth+1)
		if err != nil {
			return fmt.Errorf("include failed: %w", err)
		}

		// Merge included content into current node
		if len(includedNode.Content) > 0 {
			includedContent := includedNode.Content[0]
			*node = *includedContent
		}
		return nil
	}

	// Recursively process child nodes
	for i := 0; i < len(node.Content); i++ {
		child := node.Content[i]

		// For mapping nodes, only process values (odd indices)
		if node.Kind == yaml.MappingNode && i%2 == 1 {
			if err := l.processIncludes(child, baseDir, depth); err != nil {
				return err
			}
			continue
		}

		if err := l.processIncludes(child, baseDir, depth); err != nil {
			return err
		}
	}

	return nil
}

func (l *Loader) findFile(filename string) (string, error) {
	// Try absolute path or explicit relative path
	if filepath.IsAbs(filename) || strings.HasPrefix(filename, ".") {
		if _, err := os.Stat(filename); err == nil {
			return filename, nil
		}
	}

	return "", fmt.Errorf("file %s not found", filename)
}

// Helper function to merge two YAML nodes
func (l *Loader) mergeNodes(dest, src *yaml.Node) error {
	if dest.Kind != src.Kind {
		return fmt.Errorf("cannot merge different node kinds: %v and %v", dest.Kind, src.Kind)
	}

	switch dest.Kind {
	case yaml.MappingNode:
		return l.mergeMappingNodes(dest, src)
	case yaml.SequenceNode:
		dest.Content = append(dest.Content, src.Content...)
	default:
		dest.Value = src.Value
	}
	return nil
}

func (l *Loader) mergeMappingNodes(dest, src *yaml.Node) error {
	// Create a map of existing keys for quick lookup
	keyMap := make(map[string]int)
	for i := 0; i < len(dest.Content); i += 2 {
		keyMap[dest.Content[i].Value] = i + 1 // Store index of value node
	}

	// Merge src keys into dest
	for i := 0; i < len(src.Content); i += 2 {
		key := src.Content[i]
		value := src.Content[i+1]

		if idx, exists := keyMap[key.Value]; exists {
			// Key exists, merge the values
			if err := l.mergeNodes(dest.Content[idx], value); err != nil {
				return fmt.Errorf("failed to merge key %s: %w", key.Value, err)
			}
		} else {
			// New key, append to content
			dest.Content = append(dest.Content, key, value)
		}
	}
	return nil
}

package main

import (
	"bufio"
	"encoding/base64"
	"flag"
	"fmt"
	"go/ast"
	"go/format"
	"go/parser"
	"go/token"
	"maps"
	"os"
	"path"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"text/template"
	"time"
	"unicode"
)

var appname string
var sqlFile string
var tableNames string
var prefix string
var suffix string
var confName string
var force bool
var genMode string
var group string
var hashNum string
var hashTable map[string]int

// Table 表示数据库表结构
type Table struct {
	Name       string
	OriName    string
	Comment    string
	Fields     []Field
	HasTime    bool
	PrimaryKey string
	PrimaryInt bool
	HashNum    int
	VarName    string //变量名，一般为 Name 的snake 形式，转换关键字
	Ref        string // 生成结构体的引用变量名
}

// Field 表示表字段结构
type Field struct {
	Name       string
	Type       string
	OrmType    string
	IsPrimary  bool
	IsNullable bool
	Comment    string
	Default    string
	Extra      string
	VarName    string //变量名，一般为 Name 的snake 形式，转换关键字
}

// Go 保留关键字
// {{{
var reservedKeywords = map[string]struct{}{
	"var":         {},
	"const":       {},
	"type":        {},
	"struct":      {},
	"interface":   {},
	"map":         {},
	"chan":        {},
	"if":          {},
	"else":        {},
	"for":         {},
	"range":       {},
	"switch":      {},
	"case":        {},
	"default":     {},
	"break":       {},
	"continue":    {},
	"fallthrough": {},
	"goto":        {},
	"func":        {},
	"return":      {},
	"defer":       {},
	"import":      {},
	"package":     {},
	"go":          {},
	"select":      {},
	"true":        {},
	"false":       {},
	"iota":        {},
	"nil":         {},
	"int":         {},
	"int8":        {},
	"int16":       {},
	"int32":       {},
	"int64":       {},
	"uint":        {},
	"uint8":       {},
	"uint16":      {},
	"uint32":      {},
	"uint64":      {},
	"uintptr":     {},
	"float32":     {},
	"float64":     {},
	"complex64":   {},
	"complex128":  {},
	"bool":        {},
	"string":      {},
	"byte":        {},
	"rune":        {},
	"error":       {},
	"append":      {},
	"copy":        {},
	"delete":      {},
	"panic":       {},
	"recover":     {},
	"close":       {},
	"complex":     {},
	"real":        {},
	"imag":        {},
	"len":         {},
	"cap":         {},
	"new":         {},
	"make":        {},
	//代码模板中用到的包名和变量名
	"x":  {},
	"fd": {},
} // }}}

// 临时变量
var reservedVars map[string]struct{}

// {{{
// sql 关键字
var tableLevelKeywords = map[string]struct{}{
	"CONSTRAINT": {},
	"PRIMARY":    {},
	"FOREIGN":    {},
	"KEY":        {},
	"UNIQUE":     {},
	"CHECK":      {},
	"INDEX":      {},
	"FULLTEXT":   {},
	"SPATIAL":    {},
	"LIKE":       {},
	"INHERITS":   {},
	"PARTITION":  {},
	"PARTITIONS": {},
} // }}}

var intTypes = map[string]string{
	"int":    "",
	"int8":   "",
	"int16":  "",
	"int32":  "",
	"int64":  "",
	"uint":   "",
	"uint32": "",
	"uint64": "",
}

// 映射 字段 类型到 Go 类型
var typeMappings = map[string]string{ // {{{
	"int":        "int",
	"int32":      "int32",
	"int64":      "int64",
	"uint":       "uint",
	"uint32":     "uint32",
	"uint64":     "uint64",
	"integer":    "int",
	"tinyint":    "int", //"int8" 方便处理使用 int
	"smallint":   "int", //"int16" 方便处理使用 int
	"mediumint":  "int", //"int32" 方便处理使用 int
	"bigint":     "int64",
	"string":     "string",
	"varchar":    "string",
	"char":       "string",
	"text":       "string",
	"longtext":   "string",
	"mediumtext": "string",
	"tinytext":   "string",
	"date":       "time.Time",
	"datetime":   "time.Time",
	"timestamp":  "time.Time",
	"time":       "time.Time",
	"float":      "float32",
	"double":     "float64",
	"decimal":    "float64",
	"numeric":    "float64",
	"bool":       "bool",
	"boolean":    "bool",
	"bit":        "uint",
	"binary":     "[]byte",
	"varbinary":  "[]byte",
	"blob":       "[]byte",
	"longblob":   "[]byte",
	"tinyblob":   "[]byte",
	"json":       "string",
	"enum":       "string",
	"set":        "string",
	"geometry":   "[]byte",
	"point":      "[]byte",
	"linestring": "[]byte",
	"polygon":    "[]byte",

	"datetime64":     "time.Time",
	"decimal32":      "float32",
	"decimal64":      "float64",
	"decimal128":     "float64",
	"fixedstring":    "string",
	"enum8":          "string",
	"enum16":         "string",
	"lowcardinality": "string",
	"nullable":       "interface{}",
} // }}}

// 映射 字段类型到 ORM 类型
var ormTypeMappings = map[string]string{ // {{{
	"int":        "integer",
	"int32":      "integer",
	"int64":      "integer",
	"uint":       "integer",
	"uint32":     "integer",
	"uint64":     "integer",
	"integer":    "integer",
	"tinyint":    "tinyint",
	"smallint":   "smallint",
	"mediumint":  "mediumint",
	"bigint":     "bigint",
	"string":     "string",
	"varchar":    "string",
	"char":       "char",
	"text":       "text",
	"longtext":   "longtext",
	"mediumtext": "mediumtext",
	"tinytext":   "tinytext",
	"date":       "date",
	"datetime":   "datetime",
	"timestamp":  "timestamp",
	"time":       "time",
	"float":      "float",
	"double":     "double",
	"decimal":    "decimal",
	"numeric":    "numeric",
	"bool":       "boolean",
	"boolean":    "boolean",
	"bit":        "bit",
	"binary":     "binary",
	"varbinary":  "varbinary",
	"blob":       "blob",
	"longblob":   "longblob",
	"tinyblob":   "tinyblob",
	"json":       "json",
	"enum":       "enum",
	"set":        "set",

	"datetime64":  "datetime64",
	"decimal32":   "decimal32",
	"decimal64":   "decimal64",
	"decimal128":  "decimal128",
	"fixedstring": "fixedstring",
	"enum8":       "enum8",
	"enum16":      "enum16",
} // }}}

func showHelp() { // {{{
	fmt.Println("Usage: nyx gen orm <options>")
	fmt.Println(`Options:
	-f        强制生成，如果已存在则覆盖
	-c        在配置文件中的配置名, 默认: db_master,db_slave 
	-s        sql文件名 
	-t        指定表名, 需要在 sql 文件中存在, 多个用逗号分隔, 如果指定了-p(表名前缀), 此处为去除前缀的部分，默认全部生成 
	-n        哈希分表, 格式 [{table}:{num}] 如: 'user:10' 表示user表按主键哈希分成10个表，若主键为数值类型则取模，若为字符串类型则crc32后再取模，多个表用逗号分隔, 如果指定了-p(表名前缀), 此处为去除前缀的部分
	-m        指定生成[api | rpc | svc | dao | model]文件(api、rpc 指controller文件), 多个用逗号分隔，默认全部生成
	-g        controller 分组路径, 默认无
	-p        表名前缀路径, 默认无
	-x        表名后缀路径, 默认无`)
} // }}}

func main() { // {{{

	modelDir := "./model"
	daoDir := "./dao"
	apiDir := "./controller/api"
	rpcDir := "./controller/rpc"
	svcDir := "./svc"

	//如果有更新 controller， 调用 nyx init
	controllerUpdated := false

	currentDir, err := os.Getwd()
	if err != nil {
		fmt.Println("获取当前工作目录失败:", err)
		return
	}

	appname = os.Getenv("MODULE_NAME")
	if appname == "" {
		appname = path.Base(currentDir)
	}

	//flag.StringVar(&appname, "module_name", path.Base(currentDir), "application name")
	flag.StringVar(&sqlFile, "s", "", "sql 文件名")
	flag.StringVar(&confName, "c", "", "配置文件名, 默认: db_master,db_slave")
	flag.BoolVar(&force, "f", false, "强制生成, 如果已存在则覆盖")
	flag.StringVar(&genMode, "m", "", " 指定生成[api | rpc | svc | dao | model]文件, 多个逗号分隔，默认全部生成")
	flag.StringVar(&group, "g", "", "controller 分组名, 默认无")
	flag.StringVar(&tableNames, "t", "", "指定表名, 需要在 sql 文件中存在, 多个用逗号分隔, 如果指定了-p(表名前缀), 此处为去除前缀的部分，默认全部生成")
	flag.StringVar(&prefix, "p", "", "表名前缀, 默认无")
	flag.StringVar(&suffix, "x", "", "表名前缀, 默认无")
	flag.StringVar(&hashNum, "n", "", "哈希分表, 格式 [{table}:{num}] 如: 'user:10' 表示user表按主键哈希分成10个表，若主键为数值类型则取模，若为字符串类型则crc32后再取模，多个表用逗号分隔, 如果指定了-p(表名前缀), 此处为去除前缀的部分")
	flag.Parse()

	if appname == "" || sqlFile == "" {
		showHelp()
		return
	}

	if confName != "" {
		confName = strings.ReplaceAll(strings.ReplaceAll(strings.Trim(confName, ""), " ", ""), ",", `", "`)
	}

	tableNamesArr := []string{}
	if tableNames != "" {
		tableNamesArr = strings.Split(tableNames, ",")
	}

	genModeArr := []string{}
	if genMode != "" {
		genModeArr = strings.Split(genMode, ",")
	}

	hashTable = map[string]int{}
	if hashNum != "" {
		hashs := strings.Split(hashNum, ",")
		for _, hash := range hashs {
			hts := strings.Split(hash, ":")
			if len(hts) < 2 {
				fmt.Println("\033[31m哈希分表参数不正确!\033[0m\n")
				showHelp()
				return
			}

			table := strings.TrimSpace(hts[0])
			if table == "" {
				fmt.Println("\033[31m哈希分表参数不正确!\033[0m\n")
				showHelp()
				return
			}

			num := strings.TrimSpace(hts[1])
			numint, err := strconv.Atoi(num)
			if err != nil {
				fmt.Println("\033[31m哈希分表参数不正确!\033[0m\n")
				showHelp()
				return
			}

			hashTable[table] = numint
		}
	}

	// 读取 SQL 文件
	sqlContent, err := readFile(sqlFile)
	if err != nil {
		fmt.Printf("Error reading file: %v\n", err)
		return
	}

	// 解析 SQL 文件获取表结构
	tables := parseSQL(sqlContent)

	total := len(tables)
	for _, table := range tables {
		gen := true
		if len(tableNamesArr) > 0 {
			gen = false
			for _, tname := range tableNamesArr {
				tname = strings.TrimSpace(tname)
				if strings.ToLower(tname) == toSnakeCase(table.Name) || strings.ToLower(tname) == table.OriName {
					gen = true
				}
			}
		}

		if !gen {
			total--
			continue
		}

		// 生成 model 代码
		if genMode == "" || contains(genModeArr, "model") || contains(genModeArr, "m") {
			modelCode := genModelCode(table)

			modelFile := filepath.Join(modelDir, toSnakeCase(table.Name)+"_model.go")
			// 写入输出文件
			_, err = writeFile(modelFile, modelCode)
			if err != nil {
				fmt.Printf("Error writing file: %v\n", err)
				return
			}
		}

		// 生成 dao 代码
		if genMode == "" || contains(genModeArr, "dao") || contains(genModeArr, "d") {
			daoCode := genDaoCode(table)

			daoFile := filepath.Join(daoDir, toSnakeCase(table.Name)+"_dao.go")
			// 写入输出文件
			_, err = writeFile(daoFile, daoCode)
			if err != nil {
				fmt.Printf("Error writing file: %v\n", err)
				return
			}
		}

		if genMode == "" || contains(genModeArr, "api") || contains(genModeArr, "a") {
			var baseName string
			hasBase, _ := IsFile(filepath.Join(apiDir, "base_controller.go"))
			if hasBase {
				baseName = getBaseControllerName(filepath.Join(apiDir, "base_controller.go"), "HTTP")
			}
			if baseName == "" {
				hasBase = false
				baseName = "controller.HTTP"
			}
			// 生成 controller 代码
			controllerCode := genControllerCode(table, true, hasBase, baseName)

			controllerFile := filepath.Join(apiDir, group, toSnakeCase(table.Name)+"_controller.go")
			// 写入输出文件
			controllerUpdated, err = writeFile(controllerFile, controllerCode)
			if err != nil {
				fmt.Printf("Error writing file: %v\n", err)
				return
			}
		}

		if genMode == "" || contains(genModeArr, "rpc") || contains(genModeArr, "r") {
			var baseName string
			hasBase, _ := IsFile(filepath.Join(rpcDir, "base_controller.go"))
			if hasBase {
				baseName = getBaseControllerName(filepath.Join(rpcDir, "base_controller.go"), "RPC")
			}
			if baseName == "" {
				hasBase = false
				baseName = "controller.RPC"
			}
			// 生成 controller 代码
			controllerCode := genControllerCode(table, false, hasBase, baseName)

			controllerFile := filepath.Join(rpcDir, group, toSnakeCase(table.Name)+"_controller.go")
			// 写入输出文件
			controllerUpdated, err = writeFile(controllerFile, controllerCode)
			if err != nil {
				fmt.Printf("Error writing file: %v\n", err)
				return
			}
		}

		if genMode == "" || contains(genModeArr, "svc") || contains(genModeArr, "s") {
			// 生成 svc 代码
			svcCode := genSvcCode(table)

			svcFile := filepath.Join(svcDir, group, toSnakeCase(table.Name)+"_svc.go")
			// 写入输出文件
			_, err = writeFile(svcFile, svcCode)
			if err != nil {
				fmt.Printf("Error writing file: %v\n", err)
				return
			}
		}
	}

	fmt.Printf("扫描到 %d 个表\n", total)
	if controllerUpdated {
		fmt.Println("controllers update!")
	}
} // }}}

func readFile(filename string) (string, error) { // {{{
	file, err := os.Open(filename)
	if err != nil {
		return "", err
	}
	defer file.Close()

	var lines []string
	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		lines = append(lines, scanner.Text())
	}

	return strings.Join(lines, "\n"), scanner.Err()
} // }}}

func writeFile(filename, content string) (bool, error) { // {{{
	backupDir := "./backup"

	isfile, err := IsFile(filename)
	if err != nil {
		return false, err
	}

	if isfile {
		fmt.Printf("\033[33m文件 [%s] 已存在!\033[0m\n", filename)

		if !force {
			return false, nil
		}

		bkfile := filepath.Join(backupDir, path.Base(filename)+".bak."+time.Now().Format("2006-01-02-150405"))

		if err := os.MkdirAll(path.Dir(bkfile), 0755); err != nil {
			return false, err
		}

		err = os.Rename(filename, bkfile)
		if err != nil {
			return false, err
		}

		fmt.Printf("\033[32m文件 [%s] 已备份为 [%s]!\033[0m\n", filename, bkfile)
	}

	if err := os.MkdirAll(path.Dir(filename), 0755); err != nil {
		return false, err
	}

	file, err := os.Create(filename)
	if err != nil {
		return false, err
	}
	defer file.Close()

	_, err = file.WriteString(content)
	if err != nil {
		return false, err
	}

	fmt.Printf("\033[32m成功生成文件 [%s]!\033[0m\n", filename)

	return true, nil
} // }}}

func IsFile(path string) (bool, error) { // {{{
	m, err := os.Stat(path)
	if err == nil {
		return m.Mode().IsRegular(), nil
	}
	if os.IsNotExist(err) {
		return false, nil
	}

	return false, err
} // }}}

func parseSQL(sql string) []Table { // {{{
	var tables []Table

	// 移除注释和多余空格
	sql = removeSQLComments(sql)
	sql = strings.ReplaceAll(sql, "\r\n", "\n")
	sql = strings.ReplaceAll(sql, "\r", "\n")

	// 将comment 内容转码，必须正则时干扰
	commentRe := regexp.MustCompile(`(?i)comment\s+'(.*?)'`)
	commentMatch := commentRe.FindAllStringSubmatch(sql, -1)
	for _, match := range commentMatch {

		comment := match[1]
		sql = strings.ReplaceAll(sql, "'"+comment+"'", "'"+base64.StdEncoding.EncodeToString([]byte(comment))+"'")
	}

	// 分割 SQL 语句
	statements := splitSQLStatements(sql)

	for _, stmt := range statements {
		//	if !isCreateTableStatement(stmt) {
		//		continue
		//	}

		reservedVars = maps.Clone(reservedKeywords)
		table := parseCreateTableStatement(stmt)
		if table != nil {
			tables = append(tables, *table)
		}
	}

	return tables
} // }}}

func removeSQLComments(sql string) string { // {{{
	// 移除单行注释
	sql = regexp.MustCompile(`--.*`).ReplaceAllString(sql, "")
	sql = regexp.MustCompile(`#.*`).ReplaceAllString(sql, "")
	// 移除多行注释
	sql = regexp.MustCompile(`/\*.*?\*/`).ReplaceAllString(sql, "")
	// 移除多余空格和换行
	sql = regexp.MustCompile(`\s+`).ReplaceAllString(sql, " ")
	return sql
} // }}}

func splitSQLStatements(sql string) []string {
	// 简单按分号分割，分号在字符串中的情况 已被转码
	return strings.Split(sql, ";")
}

func isCreateTableStatement(stmt string) bool {
	return strings.HasPrefix(strings.ToLower(strings.TrimSpace(stmt)), "create table")
}

func parseCreateTableStatement(stmt string) *Table { // {{{
	stmt = strings.TrimSpace(stmt)
	if len(stmt) == 0 {
		return nil
	}

	// 提取表名
	tableOriName, tableComment, body := extractTableInfo(stmt)
	if tableOriName == "" {
		return nil
	}
	tableOriName = strings.ToLower(tableOriName)

	//去除前缀
	/*
		//tableName = strings.TrimPrefix(tableName, prefix)
		prefixes := strings.Split(prefix, ",")
		for _, v := range prefixes {
			newTableName := strings.TrimPrefix(tableName, v)
			if newTableName != tableName {
				tableName = newTableName
				break
			}
		}

		//去除后缀
		suffixes := strings.Split(suffix, ",")
		for _, v := range suffixes {
			newTableName := strings.TrimSuffix(tableName, v)
			if newTableName != tableName {
				tableName = newTableName
				break
			}
		}
	*/
	prefixes := strings.Split(prefix, ",")
	suffixes := strings.Split(suffix, ",")
	tableName := TrimPrefixAndSuffix(tableOriName, prefixes, suffixes)

	ref := strings.ToLower(string(tableName[0]))
	if ref == "x" {
		ref = strings.ToLower(string(tableName[0:2]))
	}

	//ref 也加到关键字中，防止字段变量冲突
	reservedVars[ref] = struct{}{}

	// 提取字段和主键
	fields, primaryKeys := parseTableBody(body)
	if len(fields) == 0 {
		return nil
	}

	hashNum := 1
	if num, ok := hashTable[tableOriName]; ok {
		hashNum = num
	} else if num, ok := hashTable[tableName]; ok {
		hashNum = num
	}

	//处理变量名与 go 关键字冲突
	varName := getVarName(tableName)
	//if _, exists := reservedKeywords[varName]; exists {
	//	varName += "s"
	//}

	// 构建表结构
	table := &Table{
		Name:    toPascalCase(tableName),
		OriName: tableOriName,
		Comment: tableComment,
		HashNum: hashNum,
		VarName: varName,
		Ref:     ref,
	}

	for _, field := range fields {
		// 检查是否是主键
		isPrimary := false
		for _, pk := range primaryKeys {
			if pk == field.Name {
				isPrimary = true
				table.PrimaryKey = pk
				break
			}
		}

		// 处理Nullable类型
		fieldType := field.Type
		if strings.HasPrefix(strings.ToLower(fieldType), "nullable(") {
			fieldType = strings.TrimSuffix(strings.TrimPrefix(fieldType, "Nullable("), ")")
			field.IsNullable = true
		}

		goType, ok := typeMappings[strings.ToLower(fieldType)]
		if !ok {
			goType = "interface{}"
		}

		if _, ok := intTypes[goType]; ok {
			table.PrimaryInt = true
		}

		ormType, ok := ormTypeMappings[strings.ToLower(fieldType)]
		if !ok {
			ormType = fieldType
		}

		table.Fields = append(table.Fields, Field{
			Name:       toPascalCase(field.Name),
			Type:       goType,
			OrmType:    ormType,
			IsPrimary:  isPrimary,
			IsNullable: field.IsNullable,
			Comment:    field.Comment,
			Default:    field.Default,
			Extra:      field.Extra,
			VarName:    field.VarName,
		})
	}

	if table.PrimaryKey == "" {
		table.PrimaryKey = toSnakeCase(table.Fields[0].Name)
	}

	return table
} // }}}

func extractTableInfo(stmt string) (name, comment, body string) { // {{{
	// 先提取表名
	//nameRe := regexp.MustCompile(`(?i)create\s+table\s+(?:if\s+not\s+exists\s+)?([^\s(]+)`)
	//nameRe := regexp.MustCompile(`(?i)create\s+table\s+(?:if\s+not\s+exists\s+)?([\w.]+)(?:\s+on\s+cluster\s+\w+)?`)
	nameRe := regexp.MustCompile(`(?i)create\s+(?:table|dictionary)\s+(?:if\s+not\s+exists\s+)?(?:[\w.]+\.)?` + "(?:[`])?" + `(\w+)` + "(?:[`])?" + `(?:\s+on\s+cluster\s+\w+)?`)
	nameMatch := nameRe.FindStringSubmatch(stmt)

	if len(nameMatch) < 2 {
		return "", "", ""
	}
	name = strings.Trim(nameMatch[1], "`'\" ")

	// 提取注释
	commentRe := regexp.MustCompile(`(?i)comment\s*=\s*['"](.*?)['"]`)
	commentMatch := commentRe.FindStringSubmatch(stmt)
	if len(commentMatch) > 1 {
		comment = strings.Trim(commentMatch[1], "'\"")
	}

	// 提取表定义主体 - 找到第一个左括号和匹配的右括号
	start := strings.Index(stmt, "(")
	if start == -1 {
		return name, comment, ""
	}

	// 从第一个左括号开始找匹配的右括号
	parenCount := 1
	end := start + 1
	for end < len(stmt) && parenCount > 0 {
		switch stmt[end] {
		case '(':
			parenCount++
		case ')':
			parenCount--
		}
		end++
	}

	if parenCount != 0 {
		return name, comment, ""
	}

	body = stmt[start+1 : end-1]
	return name, comment, body
} // }}}

func parseTableBody(body string) ([]Field, []string) { // {{{
	var fields []Field
	var primaryKeys []string

	// 分割字段定义
	fieldDefs := splitFieldDefinitions(body)

	for _, def := range fieldDefs {
		def = strings.TrimSpace(def)
		if len(def) == 0 {
			continue
		}

		// 检查是否是主键定义
		if strings.HasPrefix(strings.ToUpper(def), "PRIMARY KEY") {
			pks := extractPrimaryKeys(def)
			primaryKeys = append(primaryKeys, pks...)
			continue
		}

		if strings.HasPrefix(strings.ToUpper(def), "UNIQUE") || strings.HasPrefix(strings.ToUpper(def), "KEY") || strings.HasPrefix(strings.ToUpper(def), "INDEX") {
			continue
		}

		// 解析字段定义
		field := parseFieldDefinition(def)
		if field != nil {
			fields = append(fields, *field)
		}
	}

	return fields, primaryKeys
} // }}}

func splitFieldDefinitions(body string) []string { // {{{
	var definitions []string
	var current strings.Builder
	parenLevel := 0

	/*
		commentRe := regexp.MustCompile(`(?i)comment\s+'(.*?)'`)
		commentMatch := commentRe.FindAllStringSubmatch(body, -1)
		for _, match := range commentMatch {

			comment := match[1]
			body = strings.ReplaceAll(body, "'"+comment+"'", "'"+base64.StdEncoding.EncodeToString([]byte(comment))+"'")
		}
	*/

	for _, r := range body {
		switch r {
		case '(':
			parenLevel++
			current.WriteRune(r)
		case ')':
			parenLevel--
			current.WriteRune(r)
		case ',':
			if parenLevel == 0 {
				definitions = append(definitions, strings.TrimSpace(current.String()))
				current.Reset()
			} else {
				current.WriteRune(r)
			}
		default:
			current.WriteRune(r)
		}
	}

	if current.Len() > 0 {
		definitions = append(definitions, strings.TrimSpace(current.String()))
	}

	return definitions
} // }}}

func extractPrimaryKeys(def string) []string { // {{{
	re := regexp.MustCompile(`(?i)primary\s+key\s*\(([^)]+)\)`)
	matches := re.FindStringSubmatch(def)
	if len(matches) < 2 {
		return nil
	}

	keys := strings.Split(matches[1], ",")
	for i := range keys {
		keys[i] = strings.Trim(keys[i], "`'\" ")
	}

	return keys
} // }}}

func parseFieldDefinition(def string) *Field { // {{{
	// 先提取注释部分，防止注释中的逗号干扰解析
	comment := ""
	commentRe := regexp.MustCompile(`(?i)comment\s+'(.*?)'`)
	commentMatch := commentRe.FindStringSubmatch(def)
	if len(commentMatch) > 1 {
		comment = commentMatch[1]
		// 临时移除注释部分进行解析
		def = strings.Replace(def, commentMatch[0], "", 1)
	}

	// 改进的字段解析正则表达式，不依赖注释部分
	re := regexp.MustCompile(`^\s*([^\s,]+)\s+([a-zA-Z0-9]+)(?:\()?(?:\s+unsigned)?(?:\s+not\s+null)?(?:\s+default\s+(?:null|'[^']*'|\d+|\([^)]*\)))?(?:\s+(auto_increment|on\s+update\s+[^\s]+))?`)
	matches := re.FindStringSubmatch(strings.ToLower(def))
	if len(matches) < 3 {
		return nil
	}

	fieldName := strings.Trim(matches[1], "`'\" ")

	if _, exists := tableLevelKeywords[strings.ToUpper(fieldName)]; exists {
		return nil
	}
	//处理变量名与 go 关键字冲突
	varName := getVarName(fieldName)
	reservedVars[varName] = struct{}{}

	//if _, exists := reservedKeywords[varName]; exists {
	//	varName += "s"
	//}

	fieldType := strings.ToLower(matches[2])
	isNullable := !strings.Contains(strings.ToLower(def), "not null")
	defaultValue := ""
	if len(matches) > 3 && matches[3] != "" {
		defaultValue = strings.TrimSpace(strings.TrimPrefix(matches[3], "default "))
		defaultValue = strings.Trim(defaultValue, "'\"")
	}
	extra := ""
	if len(matches) > 4 && matches[4] != "" {
		extra = strings.TrimSpace(matches[4])
	}

	comment_d, err := base64.StdEncoding.DecodeString(comment)
	if err != nil {
		panic(err)
	}

	return &Field{
		Name:       fieldName,
		Type:       fieldType,
		IsNullable: isNullable,
		Comment:    string(comment_d),
		Default:    defaultValue,
		Extra:      extra,
		VarName:    varName,
	}
} // }}}

func genModelCode(table Table) string { // {{{
	const ormTemplate = `package model

//此文件是由 nyx 脚手架自动生成, 可按需要修改

import (
	"github.com/nyxless/nyx/model"
	"github.com/nyxless/nyx/x"
    {{if .HasTime}}"time"{{end}}
)

{{if ne .Comment ""}}// {{.Comment}}{{end}}
type {{.Name}}Model struct {
	model.Model

    {{- range .Fields}}
    {{.Name}} {{.Type}} ` + "`" + `json:"{{.Name | toSnakeCase}}" orm:"column:{{.Name | toSnakeCase}}{{if ne .OrmType ""}};type:{{.OrmType}}{{end}}{{if .IsPrimary}};primaryKey{{end}}{{if not .IsNullable}};not null{{end}}{{if ne .Default ""}};default:{{.Default}}{{end}}{{if ne .Extra ""}};{{.Extra}}{{end}}"` + "`" + `{{if .Comment}} // {{.Comment}}{{end}}
    {{- end}}
}

// 创建空的 {{.Name}}Model
func {{.Name}}() *{{.Name}}Model {
	return &{{.Name}}Model{}
}

// 从 map 初始化 {{.Name}}Model
func New{{.Name}}Model(d x.MAP) *{{.Name}}Model {
	m := {{.Name}}()
	m.Fill(d)

	return m
}

func ({{.Ref}} *{{.Name}}Model) Fill(fd x.MAP) {
{{- range .Fields}}
	if {{.VarName | toCamelCase }}, ok := fd["{{.Name | toSnakeCase}}"]; ok {
		{{$.Ref}}.{{.Name}} = {{convertFunc .Type (.VarName | toCamelCase) }}
	}
    {{- end}}

	{{.Ref}}.Model.Ext = x.MAP{}
}

func ({{.Ref}} *{{.Name}}Model) Map() x.MAP {
	return x.MAP{
{{- range .Fields}}
		"{{.Name | toSnakeCase}}":   {{$.Ref}}.{{.Name}},
    {{- end}}
	}
}

`

	funcMap := template.FuncMap{
		"toCamelCase":  toCamelCase,
		"toSnakeCase":  toSnakeCase,
		"toLowerCamel": toLowerCamel,
		"convertFunc":  convertFunc,
	}

	tmpl, err := template.New("orm").Funcs(funcMap).Parse(ormTemplate)
	if err != nil {
		panic(err)
	}

	if hasType(table, "time.Time") {
		table.HasTime = true
	}

	//table.Appname = appname

	var buf strings.Builder
	err = tmpl.Execute(&buf, struct {
		Table
		Appname string
	}{
		Table:   table,
		Appname: appname,
	})

	if err != nil {
		panic(err)
	}

	formatted, err := format.Source([]byte(buf.String()))
	if err != nil {
		panic(err)
	}

	return string(formatted)
} // }}}

func genDaoCode(table Table) string { // {{{
	const ormTemplate = `package dao

//此文件是由 nyx 脚手架自动生成, 可按需要修改

import (
	"context"
	"fmt"
	"github.com/nyxless/nyx/dao"
	"github.com/nyxless/nyx/x"
	"github.com/nyxless/nyx/x/db"
	"{{.Appname}}/model"
)

func New{{.Name}}Dao({{if gt .HashNum 1}}id any,{{end}}tx ...db.DBClient) *{{.Name}}Dao {
	ins := &{{.Name}}Dao{}
	ins.Init({{if gt .HashNum 1}}id, {{end}}tx...)
	return ins
}

type {{.Name}}Dao struct {
	dao.Dao
}
{{if gt .HashNum 1}}//按主键(PrimaryKey)分表, id 为主键值{{end}}
func ({{.Ref}} *{{.Name}}Dao) Init({{if gt .HashNum 1}}id any, {{end}}tx ...db.DBClient) {
	if len(tx) > 0 {
		{{.Ref}}.Dao.InitTx(tx[0])
	} else {
		{{.Ref}}.Dao.Init({{if ne .ConfName ""}}"{{.ConfName}}"{{end}})
	}
	{{.Ref}}.SetTable("{{.OriName}}{{if gt .HashNum 1}}_" + {{.Ref}}.getHashNum(id){{else}}"{{end}})
	{{.Ref}}.SetPrimary("{{.PrimaryKey}}")
}

{{if gt .HashNum 1}}
func ({{.Ref}} *{{.Name}}Dao) getHashNum(id any) string {
	return x.ToString({{if .PrimaryInt}}x.AsInt(id){{else}}x.Crc32(x.AsString(id)){{end}} % {{.HashNum}})
}
{{end}}

func ({{.Ref}} *{{.Name}}Dao) WithContext(ctx context.Context) *{{.Name}}Dao {
	{{.Ref}}.Dao.WithContext(ctx)
	return {{.Ref}}
}

// 新增数据
func ({{.Ref}} *{{.Name}}Dao) Add{{.Name}}(data any) (int, error) {
	return {{.Ref}}.AddRecord(x.AsMap(data))
}

// 更新数据
func ({{.Ref}} *{{.Name}}Dao) Set{{.Name}}(data x.MAP, id any) (int, error ){
	return {{.Ref}}.SetRecord(data, id)
}

// 先尝试新增, 数据重复时更新
func ({{.Ref}} *{{.Name}}Dao) Reset{{.Name}}(data any) (int, error) {
	return {{.Ref}}.ResetRecord(x.AsMap(data))
}

// 删除数据
func ({{.Ref}} *{{.Name}}Dao) Del{{.Name}}(id any) (int, error) {
	return {{.Ref}}.DelRecord(id)
}

// 获取数据信息, 返回 map
func ({{.Ref}} *{{.Name}}Dao) Get{{.Name}}Info(id any) (x.MAP, error) {
	data, err := {{.Ref}}.GetRecord(id)
	if err != nil {
		return nil, err
	}

	if len(data) == 0 {
		return nil, fmt.Errorf("数据不存在: %v", id)
	}

	return data, nil
}

// 获取数据信息, 返回 model 对象
func ({{.Ref}} *{{.Name}}Dao) Get{{.Name}}(id any) (*model.{{.Name}}Model, error) {
	data, err := {{.Ref}}.GetRecord(id)
	if err != nil {
		return nil, err
	}

	if len(data) == 0 {
		return nil, fmt.Errorf("数据不存在: %v", id)
	}

	return model.New{{.Name}}Model(data), nil
}

// 返回带总数的列表
func ({{.Ref}} *{{.Name}}Dao) Get{{.Name}}List(page, num int, params ...any) (int, []x.MAP, error) {
	var total int
	data, err := {{.Ref}}.WithCount(&total).Limit((page-1)*num, num).GetRecords(params...)
	return total, data, err
}
`

	funcMap := template.FuncMap{
		"toPascalCase": toPascalCase,
		"toSnakeCase":  toSnakeCase,
		"toLowerCamel": toLowerCamel,
		"convertFunc":  convertFunc,
	}

	tmpl, err := template.New("orm").Funcs(funcMap).Parse(ormTemplate)
	if err != nil {
		panic(err)
	}

	if hasType(table, "time.Time") {
		table.HasTime = true
	}

	var buf strings.Builder
	err = tmpl.Execute(&buf, struct {
		Table
		Appname  string
		Prefix   string
		ConfName string
	}{
		Table:    table,
		Appname:  appname,
		Prefix:   prefix,
		ConfName: confName,
	})

	if err != nil {
		panic(err)
	}

	//return buf.String()
	formatted, err := format.Source([]byte(buf.String()))
	if err != nil {
		panic(err)
	}

	return string(formatted)
} // }}}

func genControllerCode(table Table, is_api, hasBase bool, baseName string) string { // {{{
	const ormTemplate = `package {{.Pkg}} 

//此文件是由 nyx 脚手架自动生成, 可按需要修改

import ({{if not .HasBase}}
	"github.com/nyxless/nyx/controller"{{end}}
	"github.com/nyxless/nyx/x"
	"{{.Appname}}/svc"
)

type {{.Name}}Controller struct {
	{{.BaseName}}
}

func ({{.Ref}} *{{.Name}}Controller) Get{{.Name}}InfoAction() {
	// 参数接收
	{{.PrimaryKey | toCamelCase }} := {{if .PrimaryInt}}{{.Ref}}.GetInt{{else}}{{.Ref}}.GetParam{{end}}("{{.PrimaryKey | toSnakeCase}}")

	// 拦截器
	x.Interceptor({{.PrimaryKey | toCamelCase}}{{if .PrimaryInt}} > 0{{else}} != ""{{end}}, x.ERR_PARAMS, "{{.PrimaryKey | toSnakeCase}}")

	// 业务逻辑
	{{.Name | toLowerCamel}}Svc := svc.New{{.Name}}Svc()
	{{.Name | toLowerCamel}}Info, err := {{.Name | toLowerCamel}}Svc.Get{{.Name}}({{.PrimaryKey | toCamelCase}})

	x.Interceptor(err == nil, x.ERR_OTHER, err)

	{{.Ref}}.Render({{.Name | toLowerCamel}}Info)
}

func ({{.Ref}} *{{.Name}}Controller) Get{{.Name}}ListAction() {
	// 参数接收
	page := {{.Ref}}.GetInt("page", 1)
	num := {{.Ref}}.GetInt("num", 50)

	// 拦截器
	x.Interceptor(page > 0, x.ERR_PARAMS, "page")
	x.Interceptor(num > 0, x.ERR_PARAMS, "num")

	// 业务逻辑
	{{.Name | toLowerCamel}}Svc := svc.New{{.Name}}Svc()
	total, {{.Name | toLowerCamel}}List, _ := {{.Name | toLowerCamel}}Svc.Get{{.Name}}List(page, num)

	res := x.MAP{
		"total":    total,
		"{{.Name | toSnakeCase}}_list": {{.Name | toLowerCamel}}List,
	}

	{{.Ref}}.Render(res)
}

func ({{.Ref}} *{{.Name}}Controller) Add{{.Name}}Action() {
	// 参数接收
	{{- range .Fields}}{{if and (ne .Default "auto_increment") (ne .Type "time.Time")}}
	{{.VarName | toCamelCase}} := {{convertGetFunc $.Ref .Type (.Name | toSnakeCase)}}{{end}}
    {{- end}}

	// 参数检查拦截器
	{{- range .Fields}}{{if and (ne .Default "auto_increment") (ne .Type "time.Time")}}
	x.Interceptor({{convertInterceptorFunc .Type (.VarName | toCamelCase)}}, x.ERR_PARAMS, "{{.Name | toSnakeCase}}"){{end}}
    {{- end}}

	// 业务逻辑, 注意根据需要增删字段
	{{.Name | toLowerCamel}}Info := x.MAP{
{{- range .Fields}}{{if ne .Default "auto_increment"}}
		"{{.Name | toSnakeCase}}": {{if eq .Type "time.Time"}}x.NowTime(){{else}}{{.VarName | toCamelCase}}{{end}},{{end}}{{- end}}
	}

	{{.Name | toLowerCamel}}Svc := svc.New{{.Name}}Svc()
	err := {{.Name | toLowerCamel}}Svc.Add{{.Name}}({{.Name | toLowerCamel}}Info)
	x.Interceptor(err == nil, x.ERR_OTHER, err)

	{{.Ref}}.Render()
}

func ({{.Ref}} *{{.Name}}Controller) Set{{.Name}}Action() {
	// 参数接收
	{{- range .Fields}}{{if ne .Type "time.Time"}}
	{{.VarName | toCamelCase}} := {{convertGetFunc $.Ref .Type (.Name | toSnakeCase)}}{{end}}
    {{- end}}

	// 参数检查拦截器
	{{- range .Fields}}{{if ne .Type "time.Time"}}
	x.Interceptor({{convertInterceptorFunc .Type (.VarName | toCamelCase)}}, x.ERR_PARAMS, "{{.Name | toSnakeCase}}"){{end}}
    {{- end}}

	// 业务逻辑, 注意根据需要增删字段
	{{.Name | toLowerCamel}}Info := x.MAP{
{{- range .Fields}}
		"{{.Name | toSnakeCase}}": {{if eq .Type "time.Time"}}x.NowTime(){{else}}{{.VarName | toCamelCase}}{{end}},{{- end}}
	}

	{{.Name | toLowerCamel}}Svc := svc.New{{.Name}}Svc()
	err := {{.Name | toLowerCamel}}Svc.Set{{.Name}}({{.Name | toLowerCamel}}Info, {{.PrimaryKey | toCamelCase}})
	x.Interceptor(err == nil, x.ERR_OTHER, err)

	{{.Ref}}.Render()
}

func ({{.Ref}} *{{.Name}}Controller) Del{{.Name}}Action() {
	// 参数接收
	{{.PrimaryKey | toCamelCase}} := {{if .PrimaryInt}}{{.Ref}}.GetInt{{else}}{{.Ref}}.GetParam{{end}}("{{.PrimaryKey | toSnakeCase}}")

	// 拦截器
	x.Interceptor({{.PrimaryKey | toCamelCase}}{{if .PrimaryInt}} > 0{{else}} != ""{{end}}, x.ERR_PARAMS, "{{.PrimaryKey | toSnakeCase}}")

	// 业务逻辑
	{{.Name | toLowerCamel}}Svc := svc.New{{.Name}}Svc()
	err := {{.Name | toLowerCamel}}Svc.Del{{.Name}}({{.PrimaryKey | toCamelCase}})
	x.Interceptor(err == nil, x.ERR_OTHER, err)

	{{.Ref}}.Render()
}
`

	funcMap := template.FuncMap{
		"toCamelCase":            toCamelCase,
		"toSnakeCase":            toSnakeCase,
		"toLowerCamel":           toLowerCamel,
		"convertFunc":            convertFunc,
		"convertGetFunc":         convertGetFunc,
		"convertInterceptorFunc": convertInterceptorFunc,
	}

	tmpl, err := template.New("orm").Funcs(funcMap).Parse(ormTemplate)
	if err != nil {
		panic(err)
	}

	if hasType(table, "time.Time") {
		table.HasTime = true
	}

	//table.Appname = appname

	var pkg string
	if is_api {
		pkg = "api"
	} else {
		pkg = "rpc"
	}

	if group != "" {
		pkg = path.Base(group)
	}

	var buf strings.Builder
	err = tmpl.Execute(&buf, struct {
		Table
		Appname  string
		ConfName string
		Group    string
		Pkg      string
		HasBase  bool
		IsApi    bool
		BaseName string
	}{
		Table:    table,
		Appname:  appname,
		ConfName: confName,
		Group:    group,
		Pkg:      pkg,
		HasBase:  hasBase,
		IsApi:    is_api,
		BaseName: baseName,
	})

	if err != nil {
		panic(err)
	}

	formatted, err := format.Source([]byte(buf.String()))
	if err != nil {
		panic(err)
	}

	return string(formatted)
} // }}}

func genSvcCode(table Table) string { // {{{
	const ormTemplate = `package svc

//此文件是由 nyx 脚手架自动生成, 可按需要修改

import (
	"context"
	"github.com/nyxless/nyx/dao/tx"
	"github.com/nyxless/nyx/svc"
	"github.com/nyxless/nyx/x"
	"{{.Appname}}/dao"
	"{{.Appname}}/model"
)

{{if ne .Comment ""}}// {{.Comment}}{{end}}
type {{.Name}}Svc struct {
	svc.Svc
}

func New{{.Name}}Svc(ctx ...context.Context) *{{.Name}}Svc{
	s := &{{.Name}}Svc{}

	if len(ctx) > 0 {
		s.WithContext(ctx[0])
	}

	return s
}

func ({{.Ref}} *{{.Name}}Svc) Get{{.Name}}Info(id any)(x.MAP, error) {
	return dao.New{{.Name}}Dao({{if gt .HashNum 1}}id{{end}}).Get{{.Name}}Info(id)
}

func ({{.Ref}} *{{.Name}}Svc) Get{{.Name}}(id any)(*model.{{.Name}}Model, error) {
	return dao.New{{.Name}}Dao({{if gt .HashNum 1}}id{{end}}).Get{{.Name}}(id)
}

func ({{.Ref}} *{{.Name}}Svc) Add{{.Name}}({{.Name | toLowerCamel}}Info x.MAP) error {
	var err error

	//使用 model 示例
	{{.Name | toLowerCamel}}Model := model.New{{.Name}}Model({{.Name | toLowerCamel}}Info)
	_, err = dao.New{{.Name}}Dao().Add{{.Name}}({{.Name | toLowerCamel}}Model)

	/*
	//不使用 model 示例
	_, err = dao.New{{.Name}}Dao().AddRecord({{.Name | toLowerCamel}}Info)
	*/
	return err
}

// 使用事务示例
func ({{.Ref}} *{{.Name}}Svc) Add{{.Name}}Tx({{.Name | toLowerCamel}}Info x.MAP) error {
	trans, err := tx.TransBegin({{if ne .ConfName ""}}"{{.ConfName}}"{{end}})
	if err != nil {
		return err
	}

	defer trans.Rollback()

	{{.Name | toLowerCamel}}Model := model.New{{.Name}}Model({{.Name | toLowerCamel}}Info)
	_, err = dao.New{{.Name}}Dao(trans).Add{{.Name}}({{.Name | toLowerCamel}}Model)
	if err != nil {
		return err
	}

	// other sql

	trans.Commit()

	return nil
}

func ({{.Ref}} *{{.Name}}Svc) Set{{.Name}}({{.Name | toLowerCamel}}Info x.MAP, id any) error {
	_, err := dao.New{{.Name}}Dao().Set{{.Name}}({{.Name | toLowerCamel}}Info, id)
	return err
}

func ({{.Ref}} *{{.Name}}Svc) Del{{.Name}}(id any) error {
	_, err := dao.New{{.Name}}Dao().Del{{.Name}}(id)
	return err
}

func ({{.Ref}} *{{.Name}}Svc) Get{{.Name}}s(params ...any) ([]x.MAP, error) {
	return dao.New{{.Name}}Dao().GetRecords(params...)
}

func ({{.Ref}} *{{.Name}}Svc) Get{{.Name}}List(page, num int, params ...any) (int, []x.MAP, error) {
	return dao.New{{.Name}}Dao().Get{{.Name}}List(page, num, params...)
}
`

	funcMap := template.FuncMap{
		"toSnakeCase":  toSnakeCase,
		"toLowerCamel": toLowerCamel,
		"convertFunc":  convertFunc,
	}

	tmpl, err := template.New("orm").Funcs(funcMap).Parse(ormTemplate)
	if err != nil {
		panic(err)
	}

	if hasType(table, "time.Time") {
		table.HasTime = true
	}

	var buf strings.Builder
	err = tmpl.Execute(&buf, struct {
		Table
		Appname  string
		Prefix   string
		ConfName string
	}{
		Table:    table,
		Appname:  appname,
		ConfName: confName,
	})

	if err != nil {
		panic(err)
	}

	formatted, err := format.Source([]byte(buf.String()))
	if err != nil {
		panic(err)
	}

	return string(formatted)
} // }}}

func hasType(table Table, typeName string) bool { // {{{
	for _, field := range table.Fields {
		if field.Type == typeName {
			return true
		}
	}

	return false
} // }}}

// snake 转 大写驼峰
func toPascalCase(s string) string { // {{{
	s = strings.Trim(s, "`'\" ")
	parts := strings.Split(s, "_")
	for i := range parts {
		parts[i] = strings.ToLower(parts[i])
		if len(parts[i]) > 0 {
			parts[i] = strings.Title(parts[i])
		}
	}
	return strings.Join(parts, "")
} // }}}

// snake 转 小写驼峰
func toCamelCase(s string) string { // {{{
	s = strings.Trim(s, "`'\" ")
	parts := strings.Split(s, "_")
	for i := range parts {
		parts[i] = strings.ToLower(parts[i])
		if i > 0 && len(parts[i]) > 0 {
			parts[i] = strings.Title(parts[i])
		}
	}
	return strings.Join(parts, "")
} // }}}

// 驼峰 转 snake
func toSnakeCase(s string) string { // {{{
	var result []rune
	for i, r := range s {
		if i > 0 && unicode.IsUpper(r) {
			result = append(result, '_')
		}
		result = append(result, unicode.ToLower(r))
	}
	return string(result)
} // }}}

// 大写驼峰转小写驼峰
func toLowerCamel(s string) string { // {{{
	if len(s) == 0 {
		return s
	}
	r := []rune(s)
	r[0] = unicode.ToLower(r[0])
	return string(r)
} // }}}

func convertFunc(t, key string) string { // {{{
	switch t {
	case "[]byte":
		return "x.AsBytes(" + key + ")"
	case "bool":
		return "x.AsBool(" + key + ")"
	case "float32":
		return "x.AsFloat32(" + key + ")"
	case "float64":
		return "x.AsFloat64(" + key + ")"
	case "int":
		return "x.AsInt(" + key + ")"
	case "int8":
		return "x.AsInt8(" + key + ")"
	case "int16":
		return "x.AsInt16(" + key + ")"
	case "int32":
		return "x.AsInt32(" + key + ")"
	case "int64":
		return "x.AsInt64(" + key + ")"
	case "interface{}":
		return key
	case "any":
		return key
	case "string":
		return "x.AsString(" + key + ")"
	case "uint":
		return "x.AsUint(" + key + ")"
	case "uint32":
		return "x.AsUint32(" + key + ")"
	case "uint64":
		return "x.AsUint64(" + key + ")"
	case "time.Time":
		return "x.AsTime(" + key + ")"
	default:
		return key
	}

} // }}}

func convertGetFunc(ref, t, key string) string { // {{{
	switch t {
	case "[]byte":
		return ref + ".GetBytes(\"" + key + "\")"
	case "bool":
		return ref + ".GetBool(\"" + key + "\")"
	case "float32":
		return ref + ".GetFloat32(\"" + key + "\")"
	case "float64":
		return ref + ".GetFloat(\"" + key + "\")"
	case "int", "uint":
		return ref + ".GetInt(\"" + key + "\")"
	case "int8":
		return ref + ".GetInt8(\"" + key + "\")"
	case "int16":
		return ref + ".GetInt16(\"" + key + "\")"
	case "int32", "uint32":
		return ref + ".GetInt32(\"" + key + "\")"
	case "int64", "uint64":
		return ref + ".GetInt64(\"" + key + "\")"
	case "string", "any", "interface{}":
		return ref + ".GetParam(\"" + key + "\")"
	case "time.Time":
		return "x.NowTime()"
	default:
		return ref + ".GetParam(\"" + key + "\")"
	}

} // }}}

func convertInterceptorFunc(t, key string) string { // {{{
	switch t {
	case "[]byte":
		return key + " != nil"
	case "float32", "float64", "int", "uint", "int8", "int16", "int32", "uint32", "int64", "uint64":
		return key + " > 0"
	case "string", "any", "interface{}":
		return key + " != \"\""
	case "time.Time":
		return "x.NowTime()"
	default:
		return key + " !=  \"\""
	}

} // }}}

// 检查字符串是否在切片中
func contains(slice []string, item string) bool { // {{{
	item = strings.TrimSpace(item)
	for _, s := range slice {
		s = strings.TrimSpace(s)
		if s == item {
			return true
		}
	}
	return false
} // }}}

func TrimLongestPrefix(s string, prefixes []string) (result string, matchedPrefix string, found bool) { // {{{
	sortedPrefixes := make([]string, len(prefixes))
	copy(sortedPrefixes, prefixes)

	// 按长度降序排序，确保先匹配最长的前缀
	sort.Slice(sortedPrefixes, func(i, j int) bool {
		if len(sortedPrefixes[i]) != len(sortedPrefixes[j]) {
			return len(sortedPrefixes[i]) > len(sortedPrefixes[j])
		}
		return sortedPrefixes[i] > sortedPrefixes[j]
	})

	// 遍历所有前缀，找到第一个匹配的（最长）
	for _, prefix := range sortedPrefixes {
		if strings.HasPrefix(s, prefix) {
			return strings.TrimPrefix(s, prefix), prefix, true
		}
	}

	return s, "", false
} // }}}

func TrimLongestSuffix(s string, suffixes []string) (result string, matchedSuffix string, found bool) { // {{{
	sortedSuffixes := make([]string, len(suffixes))
	copy(sortedSuffixes, suffixes)

	// 按长度降序排序，确保先匹配最长的后缀
	sort.Slice(sortedSuffixes, func(i, j int) bool {
		if len(sortedSuffixes[i]) != len(sortedSuffixes[j]) {
			return len(sortedSuffixes[i]) > len(sortedSuffixes[j])
		}
		return sortedSuffixes[i] > sortedSuffixes[j]
	})

	// 遍历所有后缀，找到第一个匹配的（最长）
	for _, suffix := range sortedSuffixes {
		if strings.HasSuffix(s, suffix) {
			return strings.TrimSuffix(s, suffix), suffix, true
		}
	}

	return s, "", false
} // }}}

func TrimLongestPrefixAndSuffix(s string, prefixes, suffixes []string) (result string, matchedPrefix, matchedSuffix string, foundPrefix, foundSuffix bool) { // {{{
	afterPrefix, prefix, prefixFound := TrimLongestPrefix(s, prefixes)
	finalResult, suffix, suffixFound := TrimLongestSuffix(afterPrefix, suffixes)

	return finalResult, prefix, suffix, prefixFound, suffixFound
} // }}}

// 过滤表前缀和后缀
func TrimPrefixAndSuffix(s string, prefixes, suffixes []string) string {
	result, _, _, _, _ := TrimLongestPrefixAndSuffix(s, prefixes, suffixes)
	return result
}

func getBaseControllerName(filePath string, typ string) string { // {{{
	fset := token.NewFileSet()
	node, err := parser.ParseFile(fset, filePath, nil, parser.ParseComments)
	if err != nil {
		return ""
	}

	var structName string

	ast.Inspect(node, func(n ast.Node) bool {
		// 查找结构体定义
		if typeSpec, ok := n.(*ast.TypeSpec); ok {
			if structType, ok := typeSpec.Type.(*ast.StructType); ok {
				// 检查字段
				if structType.Fields != nil {
					for _, field := range structType.Fields.List {
						// 检查是否是匿名字段且类型为a.B
						if len(field.Names) == 0 && isControllerType(field.Type, typ) {
							structName = typeSpec.Name.Name
							break
						}
					}
				}
			}
		}
		return true
	})

	return structName
} // }}}

func isControllerType(expr ast.Expr, typ string) bool { // {{{
	// 处理指针
	for {
		if starExpr, ok := expr.(*ast.StarExpr); ok {
			expr = starExpr.X
		} else {
			break
		}
	}

	// 检查是否是controller.HTTP|RPC
	if selExpr, ok := expr.(*ast.SelectorExpr); ok {
		if pkgIdent, ok := selExpr.X.(*ast.Ident); ok {
			return pkgIdent.Name == "controller" && selExpr.Sel.Name == typ
		}
	}

	return false
} // }}}

func getVarName(name string) string {
	for {
		if _, exists := reservedVars[name]; exists {
			name += "s"
		} else {
			return name
		}
	}
}

//

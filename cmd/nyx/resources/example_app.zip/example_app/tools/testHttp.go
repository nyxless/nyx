package main

import (
	"fmt"
	"github.com/nyxless/nyx/x"
	"time"
)

func main() {
	c := x.NewHttpClient()
	c.Get("http://127.0.0.1:9001/testHttp/getUserInfo?uid=1")
	for i := 1; i < 10; i++ {
		//go c.Get("http://127.0.0.1:9001/testHttp/getUserInfo?uid=" + x.AsString(i))
		fmt.Println(i)
	}

	time.Sleep(1e9)
}

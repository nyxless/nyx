package main

import (
	"encoding/json"
	"fmt"
	"go/format"
	"os"
	"sort"
	"strings"
)

// ParamInfo 参数信息
type ParamInfo struct {
	Name          string
	Type          string
	Value         interface{}
	IsNil         bool
	IsEmptyString bool
}

func main() {
	// 检查命令行参数
	if len(os.Args) < 2 {
		fmt.Println("请提供JSON格式的参数map字符串")
		fmt.Println("示例: go run main.go '{\"page\":1,\"page_size\":20,\"sort_by\":\"modify_time\",\"sort_order\":\"desc\"}'")
		return
	}

	// 获取输入的JSON字符串
	jsonStr := os.Args[1]

	// 解析JSON
	var params map[string]interface{}
	err := json.Unmarshal([]byte(jsonStr), &params)
	if err != nil {
		fmt.Printf("JSON解析失败: %v\n", err)
		return
	}

	// 获取并排序参数名
	paramNames := make([]string, 0, len(params))
	for name := range params {
		paramNames = append(paramNames, name)
	}
	sort.Strings(paramNames) // 按字母顺序排序

	// 生成代码
	code := generateCode(params, paramNames)

	// 格式化代码
	formattedCode, err := format.Source([]byte(code))
	if err != nil {
		fmt.Printf("代码格式化失败: %v\n", err)
		fmt.Println("原始代码:")
		fmt.Println(code)
		return
	}

	// 保存到文件
	filename := "generated_params.go"
	err = os.WriteFile(filename, formattedCode, 0644)
	if err != nil {
		fmt.Printf("保存文件失败: %v\n", err)
		return
	}

	fmt.Printf("代码已生成到文件: %s\n", filename)
	fmt.Println(string(formattedCode))
}

// generateCode 生成代码（按字母顺序）
func generateCode(params map[string]interface{}, sortedNames []string) string {
	var builder strings.Builder

	// 添加包名和导入
	builder.WriteString("package main\n\n")
	builder.WriteString("import (\n")
	builder.WriteString("\t\"github.com/astaxie/beego\"\n")
	builder.WriteString(")\n\n")

	// 生成参数接收代码
	builder.WriteString("func (this *Controller) HandleParams() {\n")

	// 第一段：参数接收（按字母顺序）
	for _, name := range sortedNames {
		value := params[name]
		paramInfo := detectParamType(name, value)
		line := generateGetLine(paramInfo)
		builder.WriteString("\t" + line + "\n")
	}

	builder.WriteString("\n")

	// 第二段：参数验证（按字母顺序）
	for _, name := range sortedNames {
		value := params[name]
		paramInfo := detectParamType(name, value)
		line := generateInterceptorLine(paramInfo)
		if line != "" {
			builder.WriteString("\t" + line + "\n")
		}
	}

	builder.WriteString("}\n")

	return builder.String()
}

// detectParamType 检测参数类型
func detectParamType(name string, value interface{}) ParamInfo {
	param := ParamInfo{
		Name:          name,
		Value:         value,
		IsNil:         value == nil,
		IsEmptyString: false,
	}

	if value == nil {
		param.Type = "string"
		return param
	}

	switch v := value.(type) {
	case float64:
		// JSON中的数字默认解析为float64
		if v == float64(int(v)) {
			param.Type = "int"
		} else {
			param.Type = "float64"
		}
	case string:
		param.Type = "string"
		param.IsEmptyString = v == ""
	case bool:
		param.Type = "bool"
	default:
		param.Type = "string"
	}

	return param
}

// generateGetLine 生成参数获取代码行
func generateGetLine(param ParamInfo) string {
	varName := toCamelCase(param.Name)

	switch param.Type {
	case "int":
		defaultValue := formatDefaultValue(param.Value)
		return fmt.Sprintf("%s := this.GetInt(\"%s\", %s)", varName, param.Name, defaultValue)
	case "float64":
		defaultValue := formatDefaultValue(param.Value)
		return fmt.Sprintf("%s := this.GetFloat(\"%s\", %s)", varName, param.Name, defaultValue)
	case "string":
		// 默认值为nil或空字符串时，不传递第二个参数
		if param.IsNil || param.IsEmptyString {
			return fmt.Sprintf("%s := this.GetString(\"%s\")", varName, param.Name)
		}
		defaultValue := formatDefaultValue(param.Value)
		return fmt.Sprintf("%s := this.GetString(\"%s\", %s)", varName, param.Name, defaultValue)
	case "bool":
		defaultValue := formatDefaultValue(param.Value)
		return fmt.Sprintf("%s := this.GetBool(\"%s\", %s)", varName, param.Name, defaultValue)
	default:
		if param.IsNil || param.IsEmptyString {
			return fmt.Sprintf("%s := this.GetString(\"%s\")", varName, param.Name)
		}
		defaultValue := formatDefaultValue(param.Value)
		return fmt.Sprintf("%s := this.GetString(\"%s\", %s)", varName, param.Name, defaultValue)
	}
}

// generateInterceptorLine 生成参数验证代码行
func generateInterceptorLine(param ParamInfo) string {
	varName := toCamelCase(param.Name)

	switch param.Type {
	case "int":
		return fmt.Sprintf("x.Interceptor(%s > 0, x.ERR_PARAMS, \"%s\")", varName, param.Name)
	case "float64":
		return fmt.Sprintf("x.Interceptor(%s > 0, x.ERR_PARAMS, \"%s\")", varName, param.Name)
	case "string":
		return fmt.Sprintf("x.Interceptor(%s != \"\", x.ERR_PARAMS, \"%s\")", varName, param.Name)
	case "bool":
		// bool类型不需要验证非空
		return ""
	default:
		return fmt.Sprintf("x.Interceptor(%s != \"\", x.ERR_PARAMS, \"%s\")", varName, param.Name)
	}
}

// formatDefaultValue 格式化默认值
func formatDefaultValue(value interface{}) string {
	if value == nil {
		return ""
	}

	switch v := value.(type) {
	case string:
		// 空字符串会返回""，但调用方会检查IsEmptyString，所以这里不需要特殊处理
		return fmt.Sprintf("\"%s\"", v)
	case float64:
		if v == float64(int(v)) {
			return fmt.Sprintf("%d", int(v))
		}
		return fmt.Sprintf("%g", v)
	case bool:
		return fmt.Sprintf("%v", v)
	default:
		return fmt.Sprintf("%v", v)
	}
}

// toCamelCase 转换为驼峰命名
func toCamelCase(s string) string {
	// 处理下划线命名
	parts := strings.Split(s, "_")
	for i := 1; i < len(parts); i++ {
		if len(parts[i]) > 0 {
			parts[i] = strings.ToUpper(parts[i][:1]) + parts[i][1:]
		}
	}
	return strings.Join(parts, "")
}

package main

import (
	"fmt"
	"gopkg.in/yaml.v3"
	"io/ioutil"
	"log"
	"os"
	"reflect"
	"strings"
)

// LoadAndValidateConfig 加载并验证配置
func LoadAndValidateConfig(filename string) (*Example, error) {
	// 1. 读取文件内容
	data, err := ioutil.ReadFile(filename)
	if err != nil {
		return nil, fmt.Errorf("读取配置文件失败: %w", err)
	}

	// 2. 解析为map用于校验
	var rawConfig map[string]interface{}
	if err := yaml.Unmarshal(data, &rawConfig); err != nil {
		return nil, fmt.Errorf("解析YAML失败: %w", err)
	}

	// 3. 校验所有字段是否都有对应结构体
	if err := validateConfigStructure(rawConfig, reflect.TypeOf(Example{}), ""); err != nil {
		return nil, fmt.Errorf("配置校验失败: %w", err)
	}

	// 4. 解析到结构体
	var config Example
	if err := yaml.Unmarshal(data, &config); err != nil {
		return nil, fmt.Errorf("解析到结构体失败: %w", err)
	}

	return &config, nil
}

// validateConfigStructure 递归校验配置结构
func validateConfigStructure(raw map[string]interface{}, typ reflect.Type, path string) error {
	// 遍历原始配置的每个字段
	for key, value := range raw {
		fieldPath := path + "." + key
		if path == "" {
			fieldPath = key
		}

		// 查找结构体中对应的字段
		field, found := findStructField(typ, key)
		if !found {
			return fmt.Errorf("未定义的配置项: %s", fieldPath)
		}

		// 递归校验嵌套结构
		if nestedMap, ok := value.(map[string]interface{}); ok {
			if err := validateConfigStructure(nestedMap, field.Type, fieldPath); err != nil {
				return err
			}
		}

		// 校验数组中的结构体
		if slice, ok := value.([]interface{}); ok && len(slice) > 0 {
			if firstElem, ok := slice[0].(map[string]interface{}); ok {
				if err := validateConfigStructure(firstElem, field.Type.Elem(), fieldPath+"[0]"); err != nil {
					return err
				}
			}
		}
	}
	return nil
}

// findStructField 在结构体中查找字段
func findStructField(typ reflect.Type, yamlTag string) (reflect.StructField, bool) {
	for i := 0; i < typ.NumField(); i++ {
		field := typ.Field(i)
		tag := field.Tag.Get("yaml")
		if tag == "" {
			continue
		}

		// 处理带逗号的标签（如 `yaml:"name,omitempty"`）
		tagParts := strings.Split(tag, ",")
		if tagParts[0] == yamlTag {
			return field, true
		}
	}
	return reflect.StructField{}, false
}

func main() {
	if len(os.Args) < 2 {
		fmt.Println("使用方法: go run main.go <配置文件路径>")
		os.Exit(1)
	}

	configFile := os.Args[1]
	_, err := LoadAndValidateConfig(configFile)
	if err != nil {
		log.Fatalf("配置加载失败: %v", err)
	}

}
